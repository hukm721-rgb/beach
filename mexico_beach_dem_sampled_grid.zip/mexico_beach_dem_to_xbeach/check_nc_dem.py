#!/usr/bin/env python3
"""Known-plane, axis ordering, missing-value and coverage tests for NC DEMs."""
from pathlib import Path
import tempfile
import numpy as np
from netCDF4 import Dataset
from pyproj import Transformer
from convert_nc_dem import read_dem,sample_dem


def fixture(path,reverse=False,transpose=False,missing=False):
    lat=np.array([29.94,29.95,29.96]);lon=np.array([-85.44,-85.43,-85.42])
    if reverse: lat=lat[::-1];lon=lon[::-1]
    X,Y=np.meshgrid(lon,lat);z=100*(X+85.43)+200*(Y-29.95)
    with Dataset(path,'w') as ds:
        ds.geospatial_bounds_crs='North American Datum 1983'
        ds.geospatial_bounds_vertical_crs='North American Vertical Datum 1988'
        ds.createDimension('lat',3);ds.createDimension('lon',3)
        ds.createVariable('lat','f8',('lat',))[:]=lat
        ds.createVariable('lon','f8',('lon',))[:]=lon
        v=ds.createVariable('Band1','f8',('lon','lat') if transpose else ('lat','lon'),fill_value=-99999.)
        v[:]=z.T if transpose else z;v.units='meters';v.positive='up'
        if missing: v[1,1]=-99999.


def main():
    tr=Transformer.from_crs('EPSG:4269','EPSG:26916',always_xy=True)
    qlon,qlat=np.meshgrid([-85.435,-85.425],[29.945,29.955])
    E,N=tr.transform(qlon,qlat)
    expected=100*(qlon+85.43)+200*(qlat-29.95)
    with tempfile.TemporaryDirectory() as tmp:
        root=Path(tmp)
        for reverse,transpose in ((False,False),(True,False),(False,True),(True,True)):
            p=root/f'plane_{reverse}_{transpose}.nc';fixture(p,reverse,transpose)
            lat,lon,z,attrs,crs=read_dem(p)
            bed,lon2,lat2=sample_dem(lat,lon,z,E,N,'EPSG:26916',crs)
            assert np.allclose(lon2,qlon,atol=1e-10,rtol=0)
            assert np.allclose(lat2,qlat,atol=1e-10,rtol=0)
            assert np.allclose(bed,expected,atol=1e-8,rtol=0)
        p=root/'missing.nc';fixture(p,missing=True)
        lat,lon,z,attrs,crs=read_dem(p)
        try: sample_dem(lat,lon,z,E,N,'EPSG:26916',crs)
        except ValueError as e: assert 'missing' in str(e)
        else: raise AssertionError('Missing source data were silently filled')
        p=root/'outside.nc';fixture(p)
        lat,lon,z,attrs,crs=read_dem(p)
        eo,no=tr.transform([-85.41],[29.98])
        try: sample_dem(lat,lon,z,np.array(eo),np.array(no),'EPSG:26916',crs)
        except ValueError as e: assert 'outside' in str(e)
        else: raise AssertionError('Out-of-bounds point was extrapolated')
    print('PASS: NAD83/UTM round trip, bilinear plane preservation, descending axes, transposed dimensions, missing-data rejection and no extrapolation')


if __name__=='__main__': main()
