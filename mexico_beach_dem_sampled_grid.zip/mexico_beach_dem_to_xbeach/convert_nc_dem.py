#!/usr/bin/env python3
"""Sample a rectilinear geographic NetCDF DEM onto the Fig.4 XBeach grid.

No extrapolation, no missing-value filling and no vertical datum conversion.
This creates terrain inputs, not an erodible-layer mask or validation data.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path

import numpy as np
from netCDF4 import Dataset
from pyproj import CRS,Geod,Transformer,network
from scipy.interpolate import RegularGridInterpolator

from build_xbeach_2d import HERE,make_grid,build,write_csv


def read_dem(path,variable='Band1',lat_name='lat',lon_name='lon',source_crs=None):
    with Dataset(path) as ds:
        attrs={k:str(ds.getncattr(k)) for k in ds.ncattrs()}
        lat=np.ma.asarray(ds[lat_name][:]).filled(np.nan)
        lon=np.ma.asarray(ds[lon_name][:]).filled(np.nan)
        v=ds[variable]
        z=np.ma.asarray(v[:],dtype=float).filled(np.nan)
        if lat.ndim!=1 or lon.ndim!=1 or len(lat)<2 or len(lon)<2:
            raise ValueError('Expected at least two one-dimensional lat/lon coordinates')
        if v.dimensions==(lon_name,lat_name): z=z.T
        elif v.dimensions!=(lat_name,lon_name):
            raise ValueError('DEM must have dimensions (lat,lon) or (lon,lat)')
        if z.shape!=(len(lat),len(lon)): raise ValueError('DEM shape does not match coordinates')
        if not np.isfinite(lat).all() or not np.isfinite(lon).all(): raise ValueError('Invalid coordinates')
        units=str(getattr(v,'units','')).lower()
        if units not in ('m','meter','meters','metre','metres'):
            raise ValueError('DEM units must explicitly be metres')
        positive=str(getattr(v,'positive','')).lower()
        if positive=='down': z=-z
        elif positive!='up': raise ValueError('DEM positive convention must be explicitly up or down')
    if np.all(np.diff(lat)<0): lat=lat[::-1];z=z[::-1]
    if np.all(np.diff(lon)<0): lon=lon[::-1];z=z[:,::-1]
    if not np.all(np.diff(lat)>0) or not np.all(np.diff(lon)>0):
        raise ValueError('Latitude/longitude must be strictly monotonic')
    if source_crs is None:
        declared=attrs.get('geospatial_bounds_crs','').lower()
        if '1983' in declared or 'nad83' in declared: source_crs='EPSG:4269'
        else: raise ValueError('Source horizontal CRS unclear; supply --source-crs')
    crs=CRS.from_user_input(source_crs)
    if not crs.is_geographic: raise ValueError('This reader expects geographic longitude/latitude coordinates')
    return lat,lon,z,attrs,crs


def sample_dem(lat,lon,z,E,N,target_crs,source_crs):
    target=CRS.from_user_input(target_crs)
    if not target.is_projected or any(a.unit_name!='metre' for a in target.axis_info[:2]):
        raise ValueError('Target CRS must be projected with metre units')
    inverse=Transformer.from_crs(target,source_crs,always_xy=True)
    lonq,latq=inverse.transform(E,N)
    if not np.isfinite(lonq).all() or not np.isfinite(latq).all(): raise ValueError('Coordinate transformation failed')
    interpolator=RegularGridInterpolator((lat,lon),z,method='linear',bounds_error=True)
    try: bed=interpolator(np.c_[latq.ravel(),lonq.ravel()]).reshape(E.shape)
    except ValueError as e: raise ValueError('Some model nodes fall outside actual DEM coordinate coverage') from e
    if not np.isfinite(bed).all():
        raise ValueError('DEM has missing/nonfinite donor values at model nodes; not filled or extrapolated')
    return bed,lonq,latq


def plot_results(out,lat,lon,z,E,N,bed,lonq,latq,X,Y):
    os.environ.setdefault('MPLCONFIGDIR',str(out/'matplotlib_cache'))
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib.ticker import MaxNLocator
    fig,axes=plt.subplots(1,3,figsize=(17,5.5),layout='constrained')
    ix=(lon>=lonq.min()-.004)&(lon<=lonq.max()+.004)
    iy=(lat>=latq.min()-.004)&(lat<=latq.max()+.004)
    vmin,vmax=-5,5
    p=axes[0].pcolormesh(lon[ix],lat[iy],z[np.ix_(iy,ix)],shading='nearest',cmap='terrain',vmin=vmin,vmax=vmax)
    for sl in ((0,slice(None)),(-1,slice(None)),(slice(None),0),(slice(None),-1)):
        axes[0].plot(lonq[sl],latq[sl],color='red',lw=1.4)
    axes[0].set_xlabel('NAD83 longitude (deg)');axes[0].set_ylabel('NAD83 latitude (deg)')
    axes[0].set_title('Native ~27 x 31 m DEM and estimated grid')
    axes[0].set_aspect(1/np.cos(np.deg2rad(latq.mean())))
    p=axes[1].pcolormesh(E/1000,N/1000,bed,shading='auto',cmap='terrain',vmin=vmin,vmax=vmax)
    fig.colorbar(p,ax=axes[1],label='Source-datum elevation (m)',shrink=.75,pad=.03)
    axes[1].set_xlabel('NAD83 / UTM 16N easting (km)');axes[1].set_ylabel('Northing (km)')
    axes[1].set_aspect('equal');axes[1].ticklabel_format(useOffset=False)
    axes[1].set_title('Interpolated bed; NO new terrain detail')
    j=bed.shape[0]//2
    axes[2].plot(X[j],bed[j],color='#946b38')
    axes[2].axhline(0,color='gray',ls='--',lw=.8)
    axes[2].set_xlabel('Local cross-shore x (m)');axes[2].set_ylabel('NAVD88 bed elevation (m)')
    axes[2].set_title('Middle grid row; NOT verified paper section A')
    axes[2].grid(alpha=.2)
    axes[0].xaxis.set_major_locator(MaxNLocator(4));axes[0].ticklabel_format(useOffset=False,style='plain')
    axes[1].xaxis.set_major_locator(MaxNLocator(4))
    fig.savefig(out/'dem_sampling_check.png',dpi=160);plt.close(fig)


def convert(args):
    network.set_network_enabled(False)  # no hidden grid downloads or route changes
    out=Path(args.out).resolve()
    if out.exists() and any(out.iterdir()): raise FileExistsError('Choose an empty/new --out directory')
    c=json.loads(Path(args.config).read_text(encoding='utf-8-sig'))
    target=CRS.from_user_input(args.target_crs)
    if c.get('horizontal_crs') and not CRS.from_user_input(c['horizontal_crs']).equals(target):
        raise ValueError('Configured grid CRS differs from --target-crs; do not relabel existing grid coordinates')
    lat,lon,z,attrs,source=read_dem(args.nc,args.variable,args.lat,args.lon,args.source_crs)
    X,Y,E,N,n=make_grid(c)
    bed,lonq,latq=sample_dem(lat,lon,z,E,N,target,source)
    vertical=attrs.get('geospatial_bounds_vertical_crs','')
    source_navd88='1988' in vertical.lower() or 'navd' in vertical.lower()
    if not source_navd88:
        if not args.vertical_datum: raise ValueError('Vertical datum unclear; supply --vertical-datum')
    if source_navd88 and args.vertical_datum and args.vertical_datum.upper().replace(' ','') not in ('NAVD88','NAVD1988'):
        raise ValueError('Source elevations are NAVD88; changing a label is not a vertical datum transformation')
    datum='NAVD88' if source_navd88 else args.vertical_datum
    out.mkdir(parents=True,exist_ok=True)
    c.update(horizontal_crs=target.to_string(),vertical_datum=datum,
             terrain_source_title=attrs.get('title',''),terrain_source_resolution_warning='~1 arc-second background DEM, not 1 m 2017 LiDAR',
             terrain_sampling='bilinear in NAD83 geographic coordinates; no vertical datum conversion')
    cfg=out/'grid_config_with_dem.json';cfg.write_text(json.dumps(c,indent=2)+'\n')
    for name,a in [('bed.dep',bed),('x.grd',X),('y.grd',Y),('world_easting.txt',E),('world_northing.txt',N)]:
        np.savetxt(out/name,a,fmt='%.8f')
    write_csv(out/'model_nodes_with_elevation.csv',
        ['j','i','x_local_m','y_local_m','easting_m','northing_m','longitude_deg','latitude_deg','z_m'],
        ((j,i,X[j,i],Y[j,i],E[j,i],N[j,i],lonq[j,i],latq[j,i],bed[j,i])
         for j in range(bed.shape[0]) for i in range(bed.shape[1])))
    geod=source.get_geod()
    _,_,dx=geod.inv(float(lon.mean()),float(lat.mean()),float(lon.mean()+np.median(np.diff(lon))),float(lat.mean()))
    _,_,dy=geod.inv(float(lon.mean()),float(lat.mean()),float(lon.mean()),float(lat.mean()+np.median(np.diff(lat))))
    report={'source_filename':Path(args.nc).name,'source_sha256':hashlib.sha256(Path(args.nc).read_bytes()).hexdigest(),
        'source_title':attrs.get('title'),'source_variable':args.variable,
        'source_horizontal_crs':source.to_string(),'target_horizontal_crs':target.to_string(),
        'source_vertical_datum_metadata':vertical,'vertical_datum_used':datum,'vertical_conversion_performed':False,
        'source_positive':'up after documented sign handling','source_units':'m',
        'actual_subset_shape':list(z.shape),'actual_subset_lon_extent':[float(lon.min()),float(lon.max())],
        'actual_subset_lat_extent':[float(lat.min()),float(lat.max())],
        'actual_coordinate_step_deg':{'lon':float(np.median(np.diff(lon))),'lat':float(np.median(np.diff(lat)))},
        'approximate_native_spacing_m':{'east_west':dx,'north_south':dy},
        'metadata_time_coverage_start':attrs.get('time_coverage_start'),'metadata_time_coverage_end':attrs.get('time_coverage_end'),
        'metadata_date_issued':attrs.get('date_issued'),'metadata_history':attrs.get('history'),
        'output_shape_rows_columns':list(bed.shape),'output_min_elevation_m':float(bed.min()),'output_max_elevation_m':float(bed.max()),
        'offshore_edge_elevation_range_m':[float(bed[:,0].min()),float(bed[:,0].max())],
        'landward_edge_elevation_range_m':[float(bed[:,-1].min()),float(bed[:,-1].max())],
        'sampled_lon_extent':[float(lonq.min()),float(lonq.max())],'sampled_lat_extent':[float(latq.min()),float(latq.max())],
        'paper_reproduction_status':'Background terrain reconstruction only; NOT 2017 1 m LiDAR or verified original bathymetry',
        'placement_warning':'Origin and 70 degree rotation remain estimated from Fig.4, not independently surveyed',
        'metadata_warning':'Global extent, actual_range and resolution attributes were inherited from the parent product; actual subset coordinates determine coverage and spacing',
        'not_generated':['true erodible-layer mask','raw validation observations','exact author parameters or solver revision'],
        'interpolation':'bilinear; no outside-domain extrapolation or missing-value filling'}
    (out/'dem_report.json').write_text(json.dumps(report,indent=2)+'\n')
    (out/'source_metadata.json').write_text(json.dumps(attrs,indent=2)+'\n')
    plot_results(out,lat,lon,z,E,N,bed,lonq,latq,X,Y)
    # Generate geometry + real sampled bed for both modes; leave all other
    # missing physics/forcing inputs explicitly blocked, not fabricated.
    builder_args=argparse.Namespace(config=cfg,out=out/'cases',demo=False,demo_duration=1800,
        bed_nodes=out/'bed.dep',terrain_xyz=None,erodible_nodes=None,boundary_csv=None)
    build(builder_args)
    print(json.dumps(report,indent=2))
    return report


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--nc',required=True);p.add_argument('--config',default=HERE/'grid_config.json')
    p.add_argument('--out',default=HERE/'dem_on_fig4_grid')
    p.add_argument('--variable',default='Band1');p.add_argument('--lat',default='lat');p.add_argument('--lon',default='lon')
    p.add_argument('--source-crs');p.add_argument('--target-crs',default='EPSG:26916')
    p.add_argument('--vertical-datum',help='Explicit declaration if not clear from source; NO vertical conversion is performed')
    args=p.parse_args()
    try: convert(args)
    except (OSError,ValueError,KeyError) as e: p.exit(2,str(e)+'\n')


if __name__=='__main__': main()
