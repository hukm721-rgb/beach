# 将上传的 NOAA NetCDF 高程采样到 XBeach 二维网格

输入：`Mexico_Beach_bathymetry_subset.nc`。
已完成真实数据采样，结果位于 `sampled_noaa_dem/`。不包含原始NC；请使用你已下载的文件重现。

## 数据核查结论

- 数据集：NOAA Northern Gulf Coast Digital Elevation Model，变量 `Band1`。
- 当前子集720×720；经纬度范围约−85.5000～−85.3003°、29.9000～30.0997°。
- 水平元数据：NAD83经纬度，采用EPSG:4269；输出米制网格采用NAD83 / UTM zone 16N，EPSG:26916。
- 高程元数据：NAVD88、米、向上为正。程序没有做垂直基准转换。
- 坐标数组实际间距为1角秒，约26.8米×30.8米。部分全局范围和resolution属性继承自更大的母数据集，不能替代实际坐标检查。
- 元数据列出的资料时段为1873–2003，产品发布于2010年，2016年有格式处理记录；不是论文2017年、1米LiDAR。

这份DEM适合研究区背景地形、近岸水深与初步模型搭建。把它插值到2.5米网格不会生成真实2.5米或1米地形细节，
不能据此严格验证论文中的窄沙丘形态、侵蚀和越丘衰减。

## 已生成的内容

```
sampled_noaa_dem/
  bed.dep                          77行×147列，NAVD88高程，单位米
  x.grd / y.grd                    局部计算坐标
  world_easting.txt
  world_northing.txt
  model_nodes_with_elevation.csv    节点两套坐标、经纬度、高程
  grid_config_with_dem.json         已注明EPSG:26916及NAVD88
  dem_sampling_check.png            原始像元、采样场与中间行剖面
  dem_report.json                  来源、分辨率、年代、采样范围与限制
  source_metadata.json
  validation_checks.json
  cases/
    NH/                            x/y网格、同一份真实采样bed.dep、参数模板
    SB/                            x/y网格、同一份真实采样bed.dep、参数模板
    grid/
    validation/
```

当前目标网格沿用前一包的图4估计位置：原点(652060,3313980)米、旋转70°、500×380米范围。
这不是独立核实的作者原点。NAD83/UTM16N是本次为匹配DEM而明确选用的投影，不代表已确认论文的原始CRS。

本次床面高程范围为约−3.7725～+3.8646米；海侧第一列为约−3.7725～−1.9046米。
全部11319个模型节点均在源数据范围内，无外推、无缺失填零。
NH和SB的床面文件逐字节相同。

没有生成 `erodible.dep`：DEM只描述地表/海床高程，不能推出砂层厚度或建筑道路的不可侵蚀掩码。
目前也没有生成可直接运行的 `params.txt`；缺失项在各模式目录的 `MISSING_INPUTS.txt` 中。

## 在Windows重新执行

把本包解压到英文路径，例如 `D:\mexico_beach_dem_to_xbeach`，将原始NC放在此目录，运行：

```powershell
Set-Location "D:\mexico_beach_dem_to_xbeach"
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe check_nc_dem.py
.\.venv\Scripts\python.exe convert_nc_dem.py --nc "Mexico_Beach_bathymetry_subset.nc" --out my_sampled_dem
```

输出目录非空时拒绝覆盖，请换一个新的 `--out` 名称。
若NC在其他目录，给 `--nc` 填完整路径即可。
默认使用 `grid_config.json` 的网格位置；有更准确的原点/角度时，复制并修改配置，再用 `--config my_config.json`。
如果配置已经声明其他投影，程序会拒绝悄悄改标为EPSG:26916，需要选择匹配的 `--target-crs`。

## 之后如何用于论文重建

1. 把本次床面保留为粗背景版本，便于检查海陆方向、边界与模型读入。
2. 取得研究区风暴前2017年高分辨率LiDAR/DEM，优先替换沙滩、沙丘和陆域；海侧可以保留这份背景测深。
3. 先统一水平坐标与高程基准，再处理接缝，不能直接把不同基准的数据拼接。
4. 补充不可侵蚀层、完整风暴边界和泥沙参数后再生成正式两模式案例。

示例组装命令（其中erodible.dep、边界和配置中其余参数都需要真实资料或明确记录的假设）：

```powershell
.\.venv\Scripts\python.exe build_xbeach_2d.py --config my_config.json --out my_case --bed-nodes sampled_noaa_dem\bed.dep --erodible-nodes erodible_nodes.dep --boundary-csv boundary.csv
```

水位边界也应采用一致的NAVD88基准。若水位采用MSL、潮汐基准或其他高程基准，必须先核实偏移或完成转换；
本程序不会仅通过改文件标签来转换高程。

`postprocess_2d.py` 可供后续处理已完成的模型输出。它不会从这份DEM创造观测数据或证明模型复现成功。
