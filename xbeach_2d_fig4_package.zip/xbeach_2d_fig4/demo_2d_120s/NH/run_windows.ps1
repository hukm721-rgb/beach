param([Parameter(Mandatory=$true)][string]$XBeachExe)
$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
if (-not (Test-Path ".\params.txt")) { throw "Missing real inputs; see MISSING_INPUTS.txt" }
& $XBeachExe 2>&1 | Tee-Object -FilePath console.log
if ($LASTEXITCODE -ne 0) { throw "XBeach failed; inspect console.log" }
Write-Host "Check final model time and output.nc; exit code alone is insufficient."
