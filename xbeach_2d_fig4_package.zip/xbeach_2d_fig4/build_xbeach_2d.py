#!/usr/bin/env python3
"""Generate Fig.4-like grids and guarded NH/SB input directories.

Default: grid + templates only. Real bed/forcing/mask are NEVER invented.
--demo creates explicitly labelled synthetic, fixed-bed demonstration inputs.
"""
import argparse
import csv
import hashlib
import json
import math
import os
from pathlib import Path
import shutil

import numpy as np

HERE = Path(__file__).resolve().parent


def make_grid(c):
    nx, ny = int(c['nx']), int(c['ny'])
    coarse, fine = float(c['dx_offshore_m']), float(c['dx_onshore_m'])
    length, width = float(c['cross_shore_length_m']), float(c['along_shore_length_m'])
    if not (nx>0 and ny>0 and coarse>fine>0 and c['dy_m']>0):
        raise ValueError('Need positive 2D sizes and offshore dx > onshore dx > 0')
    ncoarse_float=(length-nx*fine)/(coarse-fine)
    ncoarse=round(ncoarse_float)
    if abs(ncoarse_float-ncoarse)>1e-8 or not 0<=ncoarse<=nx:
        raise ValueError('Length, nx and two dx values do not give integer cell counts')
    if not np.isclose(width,ny*c['dy_m']):
        raise ValueError('Alongshore length must equal ny * dy')
    dx=np.r_[np.full(ncoarse,coarse),np.full(nx-ncoarse,fine)]
    x=np.r_[0.,np.cumsum(dx)]
    y=np.arange(ny+1,dtype=float)*c['dy_m']
    X,Y=np.meshgrid(x,y,indexing='xy')  # rows = alongshore; columns = cross-shore
    angle=np.deg2rad(c['rotation_ccw_deg'])
    E=c['origin_easting_m']+X*np.cos(angle)-Y*np.sin(angle)
    N=c['origin_northing_m']+X*np.sin(angle)+Y*np.cos(angle)
    return X,Y,E,N,ncoarse


def load_nodes(path, shape, name):
    a=np.loadtxt(path,encoding='utf-8-sig')
    if a.shape!=shape or not np.isfinite(a).all():
        raise ValueError(f'{name}: expected finite {shape} array; got {a.shape}')
    return a


def terrain_xyz(path,E,N):
    from scipy.interpolate import LinearNDInterpolator
    a=np.genfromtxt(path,delimiter=',',names=True,encoding='utf-8-sig')
    a=np.atleast_1d(a)
    if not {'easting_m','northing_m','z_m'}.issubset(a.dtype.names or ()):
        raise ValueError('Terrain CSV requires easting_m,northing_m,z_m')
    points=np.column_stack([a['easting_m'],a['northing_m']])
    if len(points)<3 or not np.isfinite(points).all() or not np.isfinite(a['z_m']).all():
        raise ValueError('Terrain samples must be finite and cover the entire grid')
    # UTM offsets are millions of metres, but the domain is only ~500 m.
    # Rescale for Qhull conditioning without extrapolating outside coverage.
    bed=LinearNDInterpolator(points,a['z_m'],rescale=True)(E,N)
    if not np.isfinite(bed).all():
        raise ValueError('DEM samples do not cover every node. No extrapolation or zero filling is allowed.')
    return bed


def read_boundary(path,duration):
    b=np.atleast_1d(np.genfromtxt(path,delimiter=',',names=True,encoding='utf-8-sig'))
    required=('time_s','hs_m','tp_s','surge_m','dir_from_deg','gammajsp','spread_s')
    if not set(required).issubset(b.dtype.names or ()):
        raise ValueError('Boundary CSV requires '+','.join(required))
    if len(b)<2 or not all(np.isfinite(b[k]).all() for k in required):
        raise ValueError('Need at least two finite boundary rows')
    if b['time_s'][0]!=0 or not np.isclose(b['time_s'][-1],duration):
        raise ValueError('Boundary must start at 0 and end at duration_s in grid_config.json')
    if np.any(np.diff(b['time_s'])<=0) or np.any(b['hs_m']<=0) or np.any(b['tp_s']<=0):
        raise ValueError('Boundary times must increase; Hs and Tp must be positive')
    if np.any(b['gammajsp']<=0) or np.any(b['spread_s']<=0):
        raise ValueError('Spectrum enhancement and spreading must be positive')
    if np.any((b['dir_from_deg']<0)|(b['dir_from_deg']>=360)):
        raise ValueError('Nautical incoming directions must be in [0,360)')
    return b


def empty_boundary():
    return np.zeros(0,dtype=[(n,'f8') for n in
        ('time_s','hs_m','tp_s','surge_m','dir_from_deg','gammajsp','spread_s')])


def write_csv(path, header, rows=()):
    with Path(path).open('w',newline='',encoding='utf-8') as f:
        w=csv.writer(f);w.writerow(header);w.writerows(rows)


def parameter_text(c,mode,ready,demo):
    def value(key):
        v=c.get(key)
        return str(v) if v is not None else '<REQUIRED_'+key.upper()+'>'
    mainang=(270-c['rotation_ccw_deg'])%360
    # theta limits use nautical "coming from" convention. JONSWAP table
    # directions are ALSO nautical. Local grid rotation is applied once.
    angle_min=mainang-90
    angle_max=mainang+90
    moving=not demo
    lines=[
        'gridform = xbeach','vardx = 1','posdwn = -1',
        f'nx = {c["nx"]}',f'ny = {c["ny"]}',
        'xfile = x.grd','yfile = y.grd','depfile = bed.dep',
        f'xori = {c["origin_easting_m"]}',f'yori = {c["origin_northing_m"]}',
        f'alfa = {c["rotation_ccw_deg"]}',
        f'wavemodel = {mode}',f'swave = {0 if mode=="nonh" else 1}',
        'single_dir = 0','CFL = 0.7',
        'bedfriction = manning','bedfriccoef = 0.035',
        'lateralwave = neumann','left = neumann','right = neumann',
        f'front = {"nonh_1d" if mode=="nonh" else "abs_2d"}',
        'back = '+value('rear_boundary'),
        'wbctype = jonstable','bcfile = jonstable.txt',
        f'random = {c["random"]}','tideloc = 1','zs0file = zs0.txt',
        f'sedtrans = {int(moving)}',f'morphology = {int(moving)}',
        f'avalanching = {int(moving)}']
    if moving:
        lines+=['form = vanthiel_vanrijn','D50 = '+value('D50_m'),
                'D90 = '+value('D90_m'),'por = '+value('porosity'),
                'morfac = '+value('morfac'),'morstart = '+value('morstart_s'),
                'struct = 1','ne_layer = erodible.dep']
    if mode=='nonh':
        lines+=['nhbreaker = 1']
    else:
        lines+=[f'thetamin = {angle_min}',f'thetamax = {angle_max}',
                f'dtheta = {c["direction_bin_width_deg"]}','thetanaut = 1',
                'break = roelvink1','gamma = 0.46','gamma2 = 0.34']
    variables=['zs','zb','hh']+(['H'] if mode=='surfbeat' else [])
    lines+=['tstart = 0',f'tstop = {c["duration_s"]}','tintg = 1',
            'outputformat = netcdf','outputprecision = double',
            'ncfilename = output.nc','remdryoutput = 1',
            f'nglobalvar = {len(variables)}',*variables]
    return '\n'.join(lines)+'\n'


def preview(out,X,Y,E,N,bed,ncoarse,c):
    # Use a writable user directory on Windows and Linux.
    os.environ.setdefault('MPLCONFIGDIR',str(out/'matplotlib_cache'))
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    nplot=2 if bed is not None else 1
    fig,axes=plt.subplots(1,nplot,figsize=(7*nplot,7),squeeze=False)
    ax=axes[0,0]
    for j in range(E.shape[0]): ax.plot(E[j]/1000,N[j]/1000,color='blue',lw=.27)
    for i in range(E.shape[1]): ax.plot(E[:,i]/1000,N[:,i]/1000,color='blue',lw=.27)
    ax.plot(E[:,ncoarse]/1000,N[:,ncoarse]/1000,color='#cc3a30',lw=1,label='Assumed spacing transition')
    for xx,label in ((120,f'dx = {c["dx_offshore_m"]:g} m'),(385,f'dx = {c["dx_onshore_m"]:g} m')):
        yy=c['along_shore_length_m']/2;angle=np.deg2rad(c['rotation_ccw_deg'])
        ee=c['origin_easting_m']+xx*np.cos(angle)-yy*np.sin(angle)
        nn=c['origin_northing_m']+xx*np.sin(angle)+yy*np.cos(angle)
        ax.text(ee/1000,nn/1000,label,ha='center',fontsize=10,
                bbox={'facecolor':'white','alpha':.8,'edgecolor':'none'})
    ax.scatter([E[0,0]/1000],[N[0,0]/1000],c='red',s=20,label='Estimated local origin')
    ax.set_title('Fig.4-like grid; placement estimated from image')
    ax.legend(fontsize=8,loc='upper left');ax.set_aspect('equal')
    ax.set_xlabel('Easting (km)');ax.set_ylabel('Northing (km)')
    ax.ticklabel_format(useOffset=False)
    if bed is not None:
        ax=axes[0,1]
        p=ax.pcolormesh(E/1000,N/1000,bed,shading='auto',cmap='terrain')
        fig.colorbar(p,ax=ax,label='Positive-up bed elevation (m)')
        ax.set_title('SYNTHETIC DEMO BED' if c.get('demo') else 'User-supplied terrain')
        ax.set_aspect('equal');ax.set_xlabel('Easting (km)');ax.set_ylabel('Northing (km)')
        ax.ticklabel_format(useOffset=False)
    fig.tight_layout();fig.savefig(out/'grid_preview.png',dpi=170);plt.close(fig)


def build(args):
    c=json.loads(Path(args.config).read_text(encoding='utf-8-sig'))
    out=Path(args.out).resolve()
    if out.exists() and any(out.iterdir()):
        raise FileExistsError('Output directory is not empty. Choose a new --out path.')
    out.mkdir(parents=True,exist_ok=True)
    X,Y,E,N,ncoarse=make_grid(c)
    shape=X.shape
    bed=mask=b=None
    required=[]
    source={'configuration':str(Path(args.config).resolve())}
    if args.demo:
        if args.bed_nodes or args.terrain_xyz or args.erodible_nodes or args.boundary_csv:
            raise ValueError('--demo cannot be mixed with real data arguments')
        c.update(demo=True,duration_s=args.demo_duration,rear_boundary='abs_2d')
        profile=np.interp(X,[0,100,150,180,200,215,230,245,300,500],
                              [-2,-.7,.2,2,3,2.3,4.1,2.5,3,3.2])
        bed=profile+.15*np.sin(2*np.pi*Y/380)*np.exp(-((X-220)/50)**2)
        mask=np.where(X<260,10.,0.)
        b=np.zeros(2,dtype=empty_boundary().dtype)
        b['time_s']=[0,args.demo_duration];b['hs_m']=1.;b['tp_s']=9.
        b['surge_m']=2.5;b['dir_from_deg']=(270-c['rotation_ccw_deg'])%360
        b['gammajsp']=3.3;b['spread_s']=1000
        source['data_status']='SYNTHETIC DEMONSTRATION ONLY; morphology disabled; not author data'
    else:
        if args.bed_nodes and args.terrain_xyz: raise ValueError('Choose one terrain source')
        if args.bed_nodes or args.terrain_xyz:
            if not c.get('horizontal_crs') or not c.get('vertical_datum'):
                raise ValueError('Fill horizontal_crs and vertical_datum before importing terrain')
            bed=load_nodes(args.bed_nodes,shape,'bed') if args.bed_nodes else terrain_xyz(args.terrain_xyz,E,N)
            p=Path(args.bed_nodes or args.terrain_xyz)
            source['terrain_sha256']=hashlib.sha256(p.read_bytes()).hexdigest()
        else: required.append('positive-up bed.dep or terrain XYZ covering all grid nodes')
        if args.erodible_nodes:
            mask=load_nodes(args.erodible_nodes,shape,'erodible thickness')
            if np.any(mask<0): raise ValueError('Erodible thickness cannot be negative')
            source['mask_sha256']=hashlib.sha256(Path(args.erodible_nodes).read_bytes()).hexdigest()
        else: required.append('non-erodible-layer/erodible-thickness array')
        if args.boundary_csv:
            b=read_boundary(args.boundary_csv,c['duration_s'])
            source['boundary_sha256']=hashlib.sha256(Path(args.boundary_csv).read_bytes()).hexdigest()
        else: required.append('complete boundary CSV with explicit spectrum settings')
        for name in ('D50_m','D90_m','porosity','morfac','morstart_s','rear_boundary'):
            if c.get(name) is None: required.append('configuration field '+name)
        if c.get('morfac') not in (None,1,1.0):
            raise ValueError('This builder supports morfac=1 only; accelerated physical-time conversion requires separate review')
        for name in ('D50_m','D90_m'):
            if c.get(name) is not None and c[name]<=0: raise ValueError(name+' must be positive')
        if c.get('porosity') is not None and not 0<c['porosity']<1: raise ValueError('porosity must lie in (0,1)')
        if c.get('morstart_s') is not None and not 0<=c['morstart_s']<=c['duration_s']: raise ValueError('morstart_s outside run')
        if c.get('rear_boundary') not in (None,'wall','abs_1d','abs_2d','wlevel'): raise ValueError('Invalid rear_boundary')
    if c['duration_s']<=0: raise ValueError('duration_s must be positive')
    if bed is not None and b is not None:
        depth=b['surge_m'][0]-bed[:,0]
        if np.any(depth<=.05):
            raise ValueError('Initial offshore boundary is dry/too shallow. Check bed orientation, sign and tide datum.')
    if b is not None:
        local_heading=np.deg2rad(270-b['dir_from_deg']-c['rotation_ccw_deg'])
        if np.any(np.cos(local_heading)<=0):
            raise ValueError('Some mean wave directions point out of the offshore boundary; check nautical convention and rotation')
    ready=not required
    gridfolder=out/'grid';gridfolder.mkdir()
    for name,a in [('x.grd',X),('y.grd',Y),('world_easting.txt',E),('world_northing.txt',N)]:
        np.savetxt(gridfolder/name,a,fmt='%.8f')
    write_csv(gridfolder/'nodes_world.csv',['j','i','x_local_m','y_local_m','easting_m','northing_m'],
        ((j,i,X[j,i],Y[j,i],E[j,i],N[j,i]) for j in range(shape[0]) for i in range(shape[1])))
    for dirname,mode in [('NH','nonh'),('SB','surfbeat')]:
        case=out/dirname;case.mkdir()
        shutil.copy2(gridfolder/'x.grd',case/'x.grd');shutil.copy2(gridfolder/'y.grd',case/'y.grd')
        if bed is not None: np.savetxt(case/'bed.dep',bed,fmt='%.8f')
        if mask is not None: np.savetxt(case/'erodible.dep',mask,fmt='%.8f')
        if b is not None:
            np.savetxt(case/'zs0.txt',np.c_[b['time_s'],b['surge_m']],fmt='%.8f')
            # JONSTABLE contains duration of each interval, NOT absolute time.
            waves=np.column_stack([b['hs_m'][:-1],b['tp_s'][:-1],b['dir_from_deg'][:-1],
                b['gammajsp'][:-1],b['spread_s'][:-1],np.diff(b['time_s']),
                np.full(len(b)-1,c['boundary_sample_dt_s'])])
            np.savetxt(case/'jonstable.txt',waves,fmt='%.8f')
        (case/('params.txt' if ready else 'params.template.txt')).write_text(
            parameter_text(c,mode,ready,args.demo),encoding='ascii')
        if not ready:
            (case/'MISSING_INPUTS.txt').write_text('\n'.join(required)+'\n',encoding='utf-8')
        caseinfo={'mode':mode,'ready_to_run':ready,'demo':args.demo,'configuration':c,
                  'source':source,'missing':required,'not_verified_author_case':True,
                  'recommended_windows_build':'User reports v1.24.6057-Halloween (2023-10-30); paper exact version unknown'}
        (case/'case_metadata.json').write_text(json.dumps(caseinfo,indent=2)+'\n')
        (case/'run_windows.ps1').write_text(
            'param([Parameter(Mandatory=$true)][string]$XBeachExe)\n'
            '$ErrorActionPreference = "Stop"\n'
            'Set-Location $PSScriptRoot\n'
            'if (-not (Test-Path ".\\params.txt")) { throw "Missing real inputs; see MISSING_INPUTS.txt" }\n'
            '& $XBeachExe 2>&1 | Tee-Object -FilePath console.log\n'
            'if ($LASTEXITCODE -ne 0) { throw "XBeach failed; inspect console.log" }\n'
            'Write-Host "Check final model time and output.nc; exit code alone is insufficient."\n',encoding='ascii')
    validate=out/'validation';validate.mkdir()
    write_csv(validate/'points_to_supply.csv',['id','easting_m','northing_m'])
    write_csv(validate/'observations_to_supply.csv',['id','window_start_s','hs_m','surge_m'])
    write_csv(validate/'profiles_to_supply.csv',['section','easting_m','northing_m','zb_pre_m','zb_post_m'])
    write_csv(validate/'published_hwm_REFERENCE_ONLY.csv',['id','published_max_elevation_m'],
              [('A',6.28),('B',5.46),('C',5.36)])
    write_csv(validate/'published_attenuation_REFERENCE_ONLY.csv',['stage','published_reduction_pct'],
              [('T1',''),('T2',91),('T3',35),('T4',41),('T5',89)])
    (validate/'README.txt').write_text(
        'REFERENCE_ONLY files transcribe paper Tables 5/10, not raw observations.\n'
        'Other CSV files contain headers only: supply real coordinates, time windows and surveys.\n'
        'Do not infer raw time-series RMSE, correlation or profile BSS from published summaries.\n',encoding='ascii')
    preview(out,X,Y,E,N,bed,ncoarse,c)
    info={'status':'runnable_demo_NOT_paper' if args.demo else ('assembled_user_case_NOT_verified_paper' if ready else 'grid_and_templates_only'),
          'node_shape_rows_columns':list(shape),'cells':[c['nx'],c['ny']],
          'coarse_dx_m':c['dx_offshore_m'],'fine_dx_m':c['dx_onshore_m'],
          'coarse_cells':ncoarse,'fine_cells':c['nx']-ncoarse,
          'transition_local_x_m':float(X[0,ncoarse]),'assumptions':[
            'Exactly 500 m cross-shore length; paper says approximately 500 m',
            'Single offshore-coarse/onshore-fine transition; 54/92 cells inferred conditionally',
            'World origin (652060,3313980) m and CCW angle 70 degrees estimated from figure',
            'UTM CRS and vertical datum unspecified; world placement must be verified',
            'Boundary, sediment defaults, validation data and exact paper solver are not recoverable from grid image'],
          'missing':required,'configuration':c,'source':source}
    (out/'manifest.json').write_text(json.dumps(info,indent=2)+'\n')
    print(json.dumps({'output':str(out),'status':info['status'],'shape':list(shape),
                      'coarse_cells':ncoarse,'fine_cells':c['nx']-ncoarse,'missing':required},indent=2))
    return info


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--config',default=HERE/'grid_config.json')
    p.add_argument('--out',default=HERE/'generated_2d')
    p.add_argument('--bed-nodes',help='77 rows x 147 columns, positive-up metres')
    p.add_argument('--terrain-xyz',help='CSV easting_m,northing_m,z_m; same verified CRS as world grid')
    p.add_argument('--erodible-nodes',help='77x147 array: metres of erodible thickness; 0 means hard')
    p.add_argument('--boundary-csv')
    p.add_argument('--demo',action='store_true',help='Explicit synthetic fixed-bed demo, NOT paper data')
    p.add_argument('--demo-duration',type=float,default=1800)
    args=p.parse_args()
    try: build(args)
    except (OSError,ValueError) as e: p.exit(2,str(e)+'\n')


if __name__=='__main__': main()
