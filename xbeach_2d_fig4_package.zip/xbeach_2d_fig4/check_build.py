#!/usr/bin/env python3
"""Meaningful geometry/forcing/statistics checks; does not need XBeach."""
import argparse
import copy
import json
from pathlib import Path
import tempfile
import numpy as np
from build_xbeach_2d import HERE,make_grid,build,read_boundary,terrain_xyz
from postprocess_2d import window_hs,bss


def main():
    c=json.loads((HERE/'grid_config.json').read_text())
    X,Y,E,N,n=make_grid(c)
    assert X.shape==Y.shape==E.shape==N.shape==(77,147)
    assert n==54
    assert np.sum(np.isclose(np.diff(X[0]),5))==54
    assert np.sum(np.isclose(np.diff(X[0]),2.5))==92
    assert X[0,54]==270 and X[0,-1]==500 and Y[-1,0]==380
    # Cross products detect mirrored/transposed cells; metric lengths detect
    # incorrect rotation/units. Geometry is right-handed and rotation is once.
    diE,diN=np.diff(E,axis=1)[:-1],np.diff(N,axis=1)[:-1]
    djE,djN=np.diff(E,axis=0)[:,:-1],np.diff(N,axis=0)[:,:-1]
    assert np.all(diE*djN-diN*djE>0)
    assert np.allclose(np.hypot(np.diff(E,axis=1),np.diff(N,axis=1)),np.diff(X,axis=1))
    assert np.allclose(np.hypot(np.diff(E,axis=0),np.diff(N,axis=0)),5)
    angle=np.deg2rad(c['rotation_ccw_deg'])
    de=E-c['origin_easting_m'];dn=N-c['origin_northing_m']
    assert np.allclose(de*np.cos(angle)+dn*np.sin(angle),X,atol=1e-8)
    assert np.allclose(-de*np.sin(angle)+dn*np.cos(angle),Y,atol=1e-8)
    t=np.arange(900.);eta=(2+.5*np.sin(2*np.pi*t/9))[:,None,None];depth=np.ones_like(eta)*2
    hs,dry=window_hs(eta,depth,detrending='mean')
    assert np.allclose(hs,np.sqrt(2)) and dry[0,0]==0
    depth[0]=np.nan
    hs,dry=window_hs(eta,depth)
    assert np.isnan(hs[0,0]) and np.isclose(dry[0,0],1/900)
    assert bss([1,1],[0,0],[2,2])==-3
    with tempfile.TemporaryDirectory() as tmp:
        root=Path(tmp)
        args=argparse.Namespace(config=HERE/'grid_config.json',out=root/'grid',demo=False,
            demo_duration=1800,bed_nodes=None,terrain_xyz=None,erodible_nodes=None,boundary_csv=None)
        info=build(args)
        assert info['status']=='grid_and_templates_only'
        assert not (root/'grid/NH/params.txt').exists()
        assert (root/'grid/NH/params.template.txt').exists()
        for name in ('x.grd','y.grd'):
            assert (root/'grid/NH'/name).read_bytes()==(root/'grid/SB'/name).read_bytes()
        # No fabricated bed or observations in normal mode.
        assert not (root/'grid/NH/bed.dep').exists()
        args.out=root/'demo';args.demo=True;args.demo_duration=120
        info=build(args)
        assert info['status']=='runnable_demo_NOT_paper'
        assert np.isclose(np.loadtxt(root/'demo/SB/jonstable.txt')[5],120)
        assert (root/'demo/NH/params.txt').exists()
        assert np.all(np.loadtxt(root/'demo/NH/bed.dep')[:,0]<2.5)
        # Exercise real-input assembly with explicitly synthetic fixtures.
        real=copy.deepcopy(c)
        real.update(horizontal_crs='TEST_FIXTURE_ONLY',vertical_datum='TEST_FIXTURE_ONLY',
                    D50_m=.0002,D90_m=.0003,porosity=.4,morfac=1,morstart_s=0,rear_boundary='abs_2d')
        cfg=root/'fixture_config.json';cfg.write_text(json.dumps(real))
        boundary=root/'fixture_boundary.csv'
        boundary.write_text('time_s,hs_m,tp_s,surge_m,dir_from_deg,gammajsp,spread_s\n0,1,9,2.5,200,3.3,1000\n21600,1,9,2.5,200,3.3,1000\n')
        args.config=cfg;args.out=root/'assembled_fixture';args.demo=False
        args.bed_nodes=root/'demo/NH/bed.dep';args.erodible_nodes=root/'demo/NH/erodible.dep'
        args.boundary_csv=boundary
        info=build(args)
        assert info['status']=='assembled_user_case_NOT_verified_paper'
        assert '<REQUIRED' not in (args.out/'NH/params.txt').read_text()
        assert 'morphology = 1' in (args.out/'NH/params.txt').read_text()
        for filename in ('bed.dep','erodible.dep','jonstable.txt','zs0.txt'):
            assert (args.out/'NH'/filename).read_bytes()==(args.out/'SB'/filename).read_bytes()
        xyz=root/'plane.csv'
        # DEM sample centres must cover the grid, including a margin at the
        # perimeter. Use an extended known plane, not exact convex-hull edges
        # vulnerable to UTM floating-point collinearity.
        cx=np.array([-10,510,-10,510.]);cy=np.array([-10,-10,390,390.])
        ce=c['origin_easting_m']+cx*np.cos(angle)-cy*np.sin(angle)
        cn=c['origin_northing_m']+cx*np.sin(angle)+cy*np.cos(angle)
        xyz.write_text('easting_m,northing_m,z_m\n'+''.join(
            f'{ee},{nn},{-2+.01*xx}\n' for ee,nn,xx in zip(ce,cn,cx)))
        assert np.allclose(terrain_xyz(xyz,E,N),-2+.01*X)
    print('PASS: dimensions, spacings, handedness, rotation, shared grids, missing-data gate, demo boundary, wave variance, dry masking and negative BSS')


if __name__=='__main__': main()
