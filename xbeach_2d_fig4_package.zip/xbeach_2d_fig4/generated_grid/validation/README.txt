REFERENCE_ONLY files transcribe paper Tables 5/10, not raw observations.
Other CSV files contain headers only: supply real coordinates, time windows and surveys.
Do not infer raw time-series RMSE, correlation or profile BSS from published summaries.
