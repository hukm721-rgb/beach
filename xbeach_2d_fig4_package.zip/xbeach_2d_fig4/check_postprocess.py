#!/usr/bin/env python3
"""Closed-form synthetic NetCDF integration checks; not validation data."""
import argparse
import json
from pathlib import Path
import tempfile
import numpy as np
from netCDF4 import Dataset
from postprocess_2d import run,read_table


def main():
    with tempfile.TemporaryDirectory() as tmp:
        root=Path(tmp)
        config=json.loads((Path(__file__).parent/'grid_config.json').read_text())
        config.update(nx=2,ny=1,duration_s=1800)
        X,Y=np.meshgrid([0,250,500],[0,380]);a=np.deg2rad(config['rotation_ccw_deg'])
        E=config['origin_easting_m']+X*np.cos(a)-Y*np.sin(a)
        N=config['origin_northing_m']+X*np.sin(a)+Y*np.cos(a)
        points=root/'points.csv'
        points.write_text(f'id,easting_m,northing_m\nP3,{E[0,0]},{N[0,0]}\nP4,{E[0,2]},{N[0,2]}\n')
        stages=root/'stages.csv';stages.write_text('stage,window_start_s\ntest,900\n')
        survey=root/'survey.csv'
        survey.write_text(f'section,easting_m,northing_m,zb_pre_m,zb_post_m\nA,{E[0,0]},{N[0,0]},1,0\nA,{E[0,2]},{N[0,2]},1,0\n')
        for mode in ('nonh','surfbeat'):
            case=root/mode;case.mkdir()
            (case/'case_metadata.json').write_text(json.dumps({'mode':mode,'demo':True,'configuration':config}))
            time=np.arange(1801.)
            eta=2+.0001*time[:,None,None]+np.sin(2*np.pi*time[:,None,None]/9)*np.array([.5,.4,.25])[None,None,:]
            eta=np.broadcast_to(eta,(1801,2,3)).copy()
            with Dataset(case/'output.nc','w') as ds:
                for name,n in [('globaltime',1801),('ny',2),('nx',3)]: ds.createDimension(name,n)
                ds.createVariable('globaltime','f8',('globaltime',))[:]=time
                ds.createVariable('globalx','f8',('ny','nx'))[:]=E
                ds.createVariable('globaly','f8',('ny','nx'))[:]=N
                for name in ('zs','hh','zb','H'):
                    ds.createVariable(name,'f8',('globaltime','ny','nx'),fill_value=-3.4e38)
                ds['zs'][:]=eta;ds['hh'][:]=2
                ds['zb'][:]=np.broadcast_to((1-time/1800)[:,None,None],(1801,2,3))
                ds['H'][:]=np.broadcast_to(np.array([.4,.3,.2])[None,None,:],(1801,2,3))
                for key in ('zs','hh','H'): ds[key][901,1,2]=-3.4e38
            expected=np.sqrt(2) if mode=='nonh' else np.sqrt(2)*.4
            obs=root/(mode+'_obs.csv')
            obs.write_text(f'id,window_start_s,hs_m,surge_m\nP3,900,{expected},\nP4,900,{expected/2},\n')
            args=argparse.Namespace(case=case,points=points,stages=stages,profiles=survey,
                                    observations=obs,detrend='linear',sb_average='energy')
            run(args)
            output=case/'postprocessed'
            stats=read_table(output/'point_windows.csv')
            assert len(stats)==2
            assert abs(float(stats[0]['hs_m'])-expected)<.001
            attenuation=read_table(output/'attenuation.csv')
            assert abs(float(attenuation[0]['reduction_pct'])-50)<1e-9
            assert json.loads((output/'profile_metrics.json').read_text())['A']['BSS']==1
            assert json.loads((output/'observation_metrics.json').read_text())['hs']['n']==2
            fields=np.load(output/'test_fields.npz')
            assert np.isnan(fields['hs_m'][1,2])
            assert np.isclose(fields['dry_fraction'][1,2],1/900)
    print('PASS: NH/SB NetCDF windows, rotated point coordinates, 50% wave attenuation, dry masks, observation alignment and profile BSS')


if __name__=='__main__': main()
