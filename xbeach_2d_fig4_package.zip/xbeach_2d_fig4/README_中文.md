# 图4二维网格生成与 NH / SB 输入目录

本包提供可执行的建网格代码、输入组装器和后处理脚本。
**所附图4(a)是网格图，不包含床面高程。不能据此恢复作者的真实 DEM、不可侵蚀层、原始验证数据或精确软件版本。**
这些缺失内容没有用虚构数据冒充。默认生成网格与模板；真实输入不齐时，不会生成可直接运行的 `params.txt`。

## 网格规格与推算

论文给出 `nx=146, ny=76`；海侧跨岸步长5 m、陆侧2.5 m；沿岸步长5 m。
默认取跨岸长度**恰好**500 m、沿岸380 m：

```
Ncoarse + Nfine = 146
5*Ncoarse + 2.5*Nfine = 500
```

由此得54个5 m单元、92个2.5 m单元，加密分界在局部x=270 m。
这是在“长度恰好500 m、只有一个海侧粗/陆侧细分界”条件下的重建推算；原文只说约500 m，并没有给54/92这两个数字。
数组为 **77行×147列**：行是沿岸 y，列是跨岸 x，第一列为海侧。

图像估读采用局部原点 `(E0,N0)=(652060,3313980) m`，局部X轴从世界东向逆时针旋转70°，
局部Y轴指向西北。与图中的X/Y箭头一致。这些是**估计值**，必须用实际地理资料核实。
`grid_config.json` 中可修改原点、角度、网格及数据基准。

坐标转换为：

```
E = E0 + x*cos(alpha) - y*sin(alpha)
N = N0 + x*sin(alpha) + y*cos(alpha)
```

`x.grd/y.grd` 保存局部坐标，`params` 中再用 `xori/yori/alfa` 放置到世界坐标，旋转只做一次。
`world_easting.txt/world_northing.txt` 用于GIS核对与地形采样，**不能再与非零xori/yori/alfa同时当作局部网格输入**。
图中没有说明精确UTM CRS及高程基准；程序不擅自认定WGS84或NAVD88。

## 1. Windows 安装 Python 依赖

使用Python 3.12，例如把本包解压到 `D:\xbeach_2d_fig4`，打开PowerShell：

```powershell
Set-Location "D:\xbeach_2d_fig4"
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
```

不需要重新编译你现有的Windows版XBeach，也不需要执行激活脚本。

## 2. 先生成与图4类似的网格

```powershell
.\.venv\Scripts\python.exe build_xbeach_2d.py --out my_grid
```

打开 `my_grid\grid_preview.png` 核对。目录内容为：

```
my_grid/
  manifest.json
  grid_preview.png
  grid/
    x.grd                 77行×147列，局部坐标
    y.grd                 77行×147列，局部坐标
    world_easting.txt
    world_northing.txt
    nodes_world.csv       节点号与两套坐标，可在QGIS检查
  NH/
    x.grd
    y.grd
    params.template.txt   非静水压参数模板
    MISSING_INPUTS.txt
    case_metadata.json
    run_windows.ps1
  SB/
    ...                   同一份网格，Surfbeat参数模板
  validation/
    points_to_supply.csv
    observations_to_supply.csv
    profiles_to_supply.csv
    published_*_REFERENCE_ONLY.csv
```

本包已包含一份 `generated_grid/`，可以先查看，不必立即生成。
输出目录非空时程序拒绝覆盖；重新生成请使用新的 `--out` 名称。

## 3. 导入真实二维地形和不可侵蚀层

可以导入两种地形格式之一：

1. 已在该网格上采样的 `bed_nodes.dep`：77行×147列，高程向上为正、单位米；
2. 有明确坐标基准的XYZ CSV：列名为 `easting_m,northing_m,z_m`。程序用线性插值，不向覆盖范围外补值。

GeoTIFF/DEM可先在QGIS中导出有效地形点为XYZ CSV。确认近岸水下部分有真实测深，不能把海域NoData填成0。
地形点覆盖范围应略大于模型边界，避免边缘采样落在数据凸包外；稀疏数据及内部缺测区也需先检查，凸包内线性插值本身不能识别缺测区。
所有坐标、床面高程、潮位、观测必须采用一致的水平/垂直基准。
先在自己的配置文件中填写 `horizontal_crs` 和 `vertical_datum`。

不可侵蚀层文件 `erodible_nodes.dep` 同样77×147：

- 数值为可侵蚀厚度，单位米；不是床面高程；
- 0表示不可侵蚀；
- 正厚度由土层资料或作者输入确定；
- 不会自动把整片陆地设置为不可侵蚀，也不会根据网格图捏造建筑道路。

## 4. 提供完整波浪与风暴潮边界

边界CSV需要以下列，且首末时刻覆盖完整计算时段：

```
time_s,hs_m,tp_s,surge_m,dir_from_deg,gammajsp,spread_s
```

`time_s` 是绝对模型时间，单位秒；程序把相邻时刻间隔转换为JONSTABLE的**持续时间列**。
波浪参数在每个区间内分段常数，潮位采用XBeach时间序列插值。
例如6小时、900秒更新时有25个端点时刻，对应24个波谱区间。

`dir_from_deg` 是世界坐标的nautical来向。对估计的 `alfa=70°`，沿局部+X正入射的来向是200°，
不是一维alfa=0时的270°。实际作者波向仍需核实。
`gammajsp` 是JONSWAP谱峰增强系数，与破碎参数 `gamma=0.46` 不同。

提供了 `boundary_APPROX_FROM_FIG6.csv`：Hs和潮位来自此前PDF图6数字化，Tp=9秒。
**200°波向、3.3谱峰增强、1000方向展宽是重建假设，不是作者原始输入**。
见同名provenance JSON及 `figure_digitization_provenance.json`。可用于近似重建，不能称为精确边界。

## 5. 组装正式的 NH / SB 目录

复制 `grid_config.json` 为 `my_config.json`，核实网格地理位置、基准和时长，并填写：

```
D50_m, D90_m, porosity, morfac, morstart_s, rear_boundary
```

这些量未从论文网格图中恢复，不提供冒充作者值的默认参数。
本组装器目前要求 `morfac=1`，避免形态加速导致物理时间与边界时序换算错误。
`rear_boundary` 可选wall、abs_1d、abs_2d、wlevel；选择wlevel时应另核查陆侧水位边界需求。

已有节点高程时：

```powershell
.\.venv\Scripts\python.exe build_xbeach_2d.py --config my_config.json --out my_case --bed-nodes bed_nodes.dep --erodible-nodes erodible_nodes.dep --boundary-csv boundary.csv
```

或者导入真实XYZ：

```powershell
.\.venv\Scripts\python.exe build_xbeach_2d.py --config my_config.json --out my_case --terrain-xyz terrain_xyz.csv --erodible-nodes erodible_nodes.dep --boundary-csv boundary.csv
```

只有数据完整并通过检查，两个目录才会生成 `params.txt`、`bed.dep`、`erodible.dep`、`jonstable.txt`、`zs0.txt`。
两模式的网格、地形、不可侵蚀层及边界完全相同。

共有设置采用论文给值：CFL=0.7、Manning=0.035、vanthiel_vanrijn、SB roelvink1、gamma=0.46、gamma2=0.34；
NH采用nonh、swave=0、nhbreaker=1，SB采用surfbeat、swave=1。
方向离散10°、dtbc=0.5秒、random=0等额外数值设置在配置中公开，不归为原文已披露参数。
模板采用NH的 `front=nonh_1d` 和SB的 `front=abs_2d` 作为重建边界选择，并非核实的作者设置。
这里 `nonh_1d` 是入波边界类型名称，不表示网格变成一维；两套网格仍为 `ny=76`。

## 6. 在Windows运行

```powershell
Set-Location "D:\xbeach_2d_fig4\my_case\NH"
& "D:\XBeach\xbeach.exe" 2>&1 | Tee-Object console.log

Set-Location "D:\xbeach_2d_fig4\my_case\SB"
& "D:\XBeach\xbeach.exe" 2>&1 | Tee-Object console.log
```

各目录也附有 `run_windows.ps1`。运行结束需核对 `globaltime` 的末值，不能只看进程退出码。
记录你现有Windows程序的版本1.24.6057-Halloween；论文精确版本未知，不能把它直接当作作者版本。

这两个是n=0.035的主要组合。如还要表4敏感性，从原始输入模板复制新目录，分别把Manning改为0.030和0.040，
共6个完整过程。T1–T5从每次连续计算中提取，不分开重置地形。

## 7. 可选：纯演示，不冒充论文地形

```powershell
.\.venv\Scripts\python.exe build_xbeach_2d.py --out demo_case --demo
```

它生成有明确标签的人工二维床面、恒定Hs=1米/Tp=9秒/潮位2.5米、1800秒**固定床**演示。
用于检查你自己的求解器能否读取网格和运行两个模式。不是作者数据，不用于论文侵蚀或精度结论。
演示的可侵蚀层也为人工假设，且演示中不启用地形变化。
压缩包另附 `demo_2d_120s/`：这是辅助检查用的120秒输入目录，不包含大体积模型输出，
时长不足900秒，因此不能用来统计15分钟Hs。要练习后处理，请用上面的命令生成默认1800秒演示。

## 8. 后处理及真实观测验证

`validation/*_to_supply.csv` 只有表头；填入真实坐标和观测，不把参考表格伪装成原始时序。
坐标必须是与网格一致的世界平面坐标，单位米。
点位文件可包含A、B、C、P3、P4，使用这些ID时会输出相应站点和越丘衰减。
P3/P4的真实位置不能由网格图确定，程序不代填。

`stages_to_supply.csv` 需填写每个阶段900秒窗口的起点。作者精确窗口未披露时，应注明估读依据。
不传 `--stages` 时，会处理完整的连续900秒窗口。

```powershell
.\.venv\Scripts\python.exe postprocess_2d.py --case my_case\NH --points points.csv --stages stages.csv
.\.venv\Scripts\python.exe postprocess_2d.py --case my_case\SB --points points.csv --stages stages.csv
```

可在同一次调用中追加真实观测和前后断面：

```powershell
.\.venv\Scripts\python.exe postprocess_2d.py --case my_case\NH --points points.csv --stages stages.csv --observations observations.csv --profiles profiles.csv
```

输出包括二维Hs图、压缩场数据、点位窗口统计、最大水位、P3/P4衰减、观测RMSE/相关系数、断面RMSE/BSS。
点位与断面采用最近模型节点，保存取样距离，供检查分辨率影响。
不允许坐标落在网格外。已存在后处理结果时拒绝覆盖。

NH默认使用900个一秒样本、线性去趋势后 `4*std(eta)`；可用 `--detrend mean` 仅去均值。
SB默认按瞬时Hrms的能量平均 `sqrt(2*mean(H**2))`，可用 `--sb-average arithmetic` 选择 `sqrt(2)*mean(H)`。
二者在有波群时不同；原论文未充分说明平均口径，不能把任一种实现说成已核实的作者算法。
窗口内出现干单元则该点Hs留空；不将缺失水位填0，也不删除干样本后计算一个虚假的全窗口Hs。
BSS可以为负，不裁剪到0–1。

## 验证范围

运行 `python check_build.py` 可检查尺寸、步长、网格方向、旋转、共享输入、缺失数据阻断和波高统计。
附带记录会区分“网格/代码检查通过”“人工示例的求解器检查”和“原论文二维复现”。
只有前两项可以在没有作者原始数据时验证；后者当前未完成。
