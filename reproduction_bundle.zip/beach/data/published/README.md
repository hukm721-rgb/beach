# 数据出处与含义

Ma et al., *Ocean Engineering* 292 (2024), 116590,
DOI: 10.1016/j.oceaneng.2023.116590。

这些 CSV 是从用户提供的 PDF 人工录入的**已发表结果**，并非原始观测或本项目数值模拟的输出。
不把它们用作调整数值模型参数的目标。空值保留原表的 `/`，尤其不将 T1 的 P4 当作零波高。

| 文件 | 出处 | PDF 页码 |
|---|---|---|
| boundary_stages.csv | 表 3，海侧边界 | 8 |
| manning_sensitivity.csv | 表 4 | 9 |
| water_levels.csv | 表 5，站点最大瞬时水位 | 10 |
| wave_heights.csv | 表 6，USGS 站点 Hs | 11 |
| dune_peaks.csv | 表 8 | 12 |
| breakers.csv | 表 9 | 16 |
| dune_attenuation.csv | 表 10，断面 A，P3/P4 | 16 |

`published_*` 字段逐字保留原表；重算列另写到 `results/tables/`。表内个别误差不能用显示的数值重建，
详见 `reports/reproduction.md`。输入边界 Hs（表 3）、站点 Hs（表 6）和丘前丘后 Hs（表 10）位置不同，不能互换。
