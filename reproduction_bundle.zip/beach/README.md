# 飓风波越过沙丘后的传播与衰减：论文复现

Ma et al. (2024), *Modeling hurricane wave propagation and attenuation after
overtopping sand dunes during storm surge*, **Ocean Engineering 292, 116590**。
DOI: [10.1016/j.oceaneng.2023.116590](https://doi.org/10.1016/j.oceaneng.2023.116590)。

**当前是可运行的部分复现，尚未完整重现论文的二维结果。**
论文第 18 页说明数据按请求提供；上传的 PDF 不包含原始模型输入。
本项目明确区分已发表数据的重算与使用近似输入的独立数值试算。

## 已交付

- 七张关键表的 CSV、误差与衰减率重算、对应图表；
- 图 6 边界和图 10 初始断面的可重复数字化脚本、数值与像素校准记录；
- 固定版本的官方 XBeach 镜像构建流程、非静水压和 surfbeat 模式的一维六小时试算；
- 峰值固定床试算、重复性检查及 2.5 m / 1.25 m 网格敏感性检查；
- 对公式 (6)/(7)、表格算术、缺失数据和模型版本差异的说明。

查看 [复现报告](reports/reproduction.md)、[数据索取清单](reports/data_request.md) 和
[已发表数据说明](data/published/README.md)。

## 查看结果

| 内容 | 文件 |
|---|---|
| 表格算术复核摘要 | [results/summary.json](results/summary.json) |
| 越丘波衰减率重算 | [dune_attenuation.png](results/figures/dune_attenuation.png) |
| 从原图读取的近似输入 | [digitized_inputs.png](results/figures/digitized_inputs.png) |
| 六小时非静水压断面结果 | [profiles.png](results/storm_nh/profiles.png) |
| 简化模型与论文的诊断对比 | [reduced_storm_comparison.png](results/figures/reduced_storm_comparison.png) |
| 数值运行与网格检查 | [numerical_validation.json](results/numerical_validation.json) |

## 在本云环境重新运行

```bash
cd /workspace/beach
bash scripts/reproduce.sh audit

# 已编译求解器位于 .tools/bin/xbeach；数值运行需数分钟。
# 新运行目录不会覆盖此前的原始输出；results/ 下的摘要会更新。
bash scripts/reproduce.sh numerical
```

原始 NetCDF 和运行日志保存在 `runs/`；精简结果、输入哈希、运行凭据在 `results/`。
进程需要重新启动，不能假定云环境快照保留了正在运行的模型。
直接使用现有 checkout；每个云任务已经隔离，不要另建 Git worktree。

## 在同类云基础镜像重建

要求当前云环境同类的 Debian 13 amd64 基础镜像、Python 3.12+、GCC 14 的运行库和启动对象、
`git/gcc/make/dpkg-deb/apt-get`，以及基础镜像已提供的 NetCDF C 运行依赖（HDF5、libcurl 等）。
该无 root 安装流程不承诺适用于任意空白 Linux 镜像。
安装脚本把 Python 与 Debian 软件包解压到仓库内，保留 TLS 和 Debian 索引签名/校验和检查。
需通过云环境原有代理访问 `github.com`、`deb.debian.org`、`pypi.org`、`files.pythonhosted.org`。
不需要额外密钥。

```bash
bash scripts/setup.sh
bash scripts/reproduce.sh numerical
```

若已有源码，可指定 `XBEACH_SOURCE=/path/to/xbeach`，脚本仍会验证 commit。
公开镜像的 commit 为 `6f1dd9626f57cdc0a5b306f5975ba4ce0d7a5a29`（2018-06-25），
**不能当作论文未说明的精确软件版本**。
构建脚本只在构建副本中移除未使用的 C 元数据类型的非标准 `BIND(C)`，不修改数值方程；
构建细节及二进制哈希写入 `results/solver_build.json`。

## 单独运行

```bash
.venv/bin/python -m beach_repro.audit
PYTHONPATH=. .venv/bin/python scripts/plot_inputs.py
.venv/bin/python -m beach_repro.xbeach --case runs/my_nh --mode nonh
.venv/bin/python -m beach_repro.xbeach --case runs/my_sb --mode surfbeat
.venv/bin/python -m beach_repro.xbeach --case runs/my_smoke --smoke --dx 1.25
```

数字化输入已保存，日常计算不需要 PDF。要重提取输入：

```bash
.venv/bin/python scripts/digitize_paper.py /path/to/the/supplied/paper.pdf
```

像素校准针对提供的这份 PDF，原文件 SHA-256 在 `data/digitized/provenance.json`。
不要直接用于页版不同的 PDF。

收到作者资料后，按 `configs/author_manifest.example.json` 整理输入，执行
`.venv/bin/python scripts/validate_author_inputs.py /path/to/author_case`。
该命令只检查格式，不声称已经完成二维模型复现。
