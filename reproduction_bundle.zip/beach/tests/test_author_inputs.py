import importlib.util
from pathlib import Path
import json
import numpy as np
import pytest

spec=importlib.util.spec_from_file_location('validator',Path(__file__).resolve().parents[1]/'scripts/validate_author_inputs.py')
validator=importlib.util.module_from_spec(spec);spec.loader.exec_module(validator)


def test_missing_author_data_is_a_blocker(tmp_path):
    with pytest.raises(ValueError,match='manifest'): validator.validate(tmp_path)
    (tmp_path/'manifest.json').write_text(json.dumps({'solver_version':'REQUIRED'}))
    with pytest.raises(ValueError,match='version'): validator.validate(tmp_path)


def test_full_case_requires_correct_grid_and_datum(tmp_path):
    # Synthetic arrays test the input gate only; never used as scientific data.
    manifest={'solver_version':'test-fixture','horizontal_crs':'test','vertical_datum':'test'}
    for key in ('params_nh','params_sb'):
        manifest[key]=key+'.txt';(tmp_path/manifest[key]).write_text('test fixture')
    for key in ('x_grid','y_grid','bed_pre','bed_post','erodible_thickness'):
        manifest[key]=key+'.txt';np.savetxt(tmp_path/manifest[key],np.zeros((77,147)))
    headers={'boundary_wave':'time_s,hs_m,tp_s,direction_deg\n0,1,9,270\n900,2,9,270\n',
             'boundary_surge':'time_s,surge_m\n0,3\n900,4\n',
             'gauge_observations':'time_s,eta_m\n0,3\n1,3.1\n',
             'station_locations':'id,x_m,y_m\nA,0,0\nB,10,10\n'}
    for key,text in headers.items():
        manifest[key]=key+'.csv';(tmp_path/manifest[key]).write_text(text)
    (tmp_path/'manifest.json').write_text(json.dumps(manifest))
    assert validator.validate(tmp_path)['status']=='input_shapes_checked'
    np.savetxt(tmp_path/manifest['bed_pre'],np.zeros((76,146)))
    with pytest.raises(ValueError,match='77,147'): validator.validate(tmp_path)
