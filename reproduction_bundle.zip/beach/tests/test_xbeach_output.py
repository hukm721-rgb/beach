import json
import numpy as np
from netCDF4 import Dataset
import pytest
from beach_repro.xbeach import validate_output,arrays


def fixture(case):
    (case/'case.json').write_text(json.dumps({'tstop_s':2}))
    with Dataset(case/'xboutput.nc','w') as ds:
        for name,size in [('globaltime',3),('ny',1),('nx',2)]: ds.createDimension(name,size)
        ds.createVariable('globaltime','f8',('globaltime',))[:]=[0,1,2]
        ds.createVariable('globalx','f8',('ny','nx'))[:]=[[0,2.5]]
        for key,vals in [('zb',[-1,-1]),('zs',[1,1]),('hh',[2,2]),('H',[0,0])]:
            a=ds.createVariable(key,'f8',('globaltime','ny','nx'),fill_value=-3.4e38)
            a[:]=np.tile(vals,(3,1,1))
        ds['zs'][0,0,1]=-3.4e38;ds['hh'][0,0,1]=-3.4e38;ds['H'][0,0,1]=-3.4e38


def test_native_dry_masks_are_retained_not_counted_as_instability(tmp_path):
    fixture(tmp_path)
    receipt=validate_output(tmp_path)
    assert receipt['dry_masked_surface_values']==1
    t,x,a=arrays(tmp_path)
    assert np.isnan(a['zs'][0,1])
    assert a['zb'][0,1]==-1


def test_wet_nan_is_a_failure(tmp_path):
    fixture(tmp_path)
    with Dataset(tmp_path/'xboutput.nc','a') as ds: ds['zs'][1,0,0]=np.nan
    with pytest.raises(RuntimeError,match='Nonfinite'): validate_output(tmp_path)


def test_mismatched_surface_depth_masks_are_a_failure(tmp_path):
    fixture(tmp_path)
    with Dataset(tmp_path/'xboutput.nc','a') as ds: ds['hh'][0,0,1]=0
    with pytest.raises(RuntimeError,match='masks differ'): validate_output(tmp_path)
