import json
from pathlib import Path
import numpy as np
import pytest
from beach_repro.audit import ROOT, run, read_csv
from beach_repro.xbeach import prepare


def test_published_arithmetic_not_confused_with_simulation(tmp_path):
    s=run(tmp_path)
    assert s['attenuation_pct_from_rounded_heights']['T1'] is None
    assert s['attenuation_pct_from_rounded_heights']['T4']==pytest.approx(42.53731343283582)
    assert s['wave_heights']['nh']['mean_published_pct']==pytest.approx(2.382)
    assert s['wave_heights']['sb']['mean_published_pct']==pytest.approx(16.92)
    assert s['dune_peaks_signed_mean_error_m']['nh']==pytest.approx(-.01)
    assert len(list((tmp_path/'figures').glob('*.png')))==3
    json.loads((tmp_path/'summary.json').read_text())


def test_digitized_inputs_remain_physical():
    d=np.genfromtxt(ROOT/'data/digitized/section_a_pre.csv',delimiter=',',names=True)
    assert d['x_m'][0]==0 and d['x_m'][-1]==500
    assert np.all(np.diff(d['x_m'])>0)
    assert -2.2<d['z_m'][0]<-1.5
    assert 3.8<np.max(d['z_m'])<4.4
    b=np.genfromtxt(ROOT/'data/digitized/boundary_15min.csv',delimiter=',',names=True)
    assert np.all(np.diff(b['time_s'])==900)
    assert b['time_s'][-1]==21600
    assert np.max(b['hs_m'])>2
    assert 4.6<np.max(b['surge_m'])<4.9


def test_case_generation_sign_and_boundary_conventions(tmp_path):
    case=tmp_path/'nh'
    m=prepare(case,'nonh')
    x=np.loadtxt(case/'x.grd');z=np.loadtxt(case/'bed.dep')
    assert x.shape==z.shape==(201,)
    assert z[0]<0  # positive-up bed, consistent with posdwn=-1
    assert m['tstop_s']==21600 and m['ny']==0
    assert m['morphology'] is True
    params=(case/'params.txt').read_text()
    assert 'posdwn = -1' in params and 'bedfriction = manning' in params
    w=np.loadtxt(case/'waves.txt')
    assert w.shape==(25,7)
    assert np.all(w[:,2]==270) and np.all(w[:,5]==900)
    with pytest.raises(FileExistsError): prepare(case)
