import numpy as np
import pytest
from beach_repro.metrics import significant_height, literal_paper_hs, brier_skill, jonswap, reduction_percent


def test_wave_variance_with_offset_and_trend():
    t=np.arange(900.)
    wave=.5*np.sin(2*np.pi*t/9)
    # For an Airy monochromatic wave of amplitude a, Hm0=2*sqrt(2)*a,
    # which differs from crest-to-trough 2a. Tests the physical convention.
    assert significant_height(4.72+wave)==pytest.approx(np.sqrt(2),rel=1e-12)
    assert significant_height(4.72+.001*t+wave,linear_detrend=True)==pytest.approx(np.sqrt(2),rel=.001)


def test_literal_formula_has_sampling_dependence():
    estimates=[]
    for dt in (1.,.1):
        t=np.arange(0,900,dt);eta=.5*np.sin(2*np.pi*t/9)
        estimates.append(literal_paper_hs(eta))
        assert significant_height(eta)==pytest.approx(np.sqrt(2),rel=1e-12)
    assert estimates[0]/estimates[1]>3


def test_dry_or_missing_values_are_not_silently_zeroed():
    assert np.isnan(reduction_percent(1.,np.nan))
    assert np.isnan(reduction_percent(0.,0.))
    with pytest.raises(ValueError): significant_height([1,np.nan,2])
    assert reduction_percent(1.78,1.16)==pytest.approx(34.83146067415731)


def test_jonswap_energy_and_peak():
    f=np.linspace(0,.6,6001)
    s=jonswap(f,2.03,9)
    assert np.isfinite(s).all()
    assert np.trapezoid(s,f)==pytest.approx((2.03/4)**2,rel=1e-12)
    assert f[np.argmax(s)]==pytest.approx(1/9,abs=.001)


def test_bss_can_be_negative():
    assert brier_skill([1,1],[0,0],[0,0])==1
    assert brier_skill([1,1],[0,0],[1,1])==0
    assert brier_skill([1,1],[0,0],[2,2])==-3
    with pytest.raises(ValueError): brier_skill([1,1],[1,1],[0,0])
