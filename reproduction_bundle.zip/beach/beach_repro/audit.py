"""Recalculate table arithmetic. Does not run a numerical coastal model."""
import csv
import json
import os
from pathlib import Path

os.environ.setdefault('MPLCONFIGDIR', '/tmp/beach-matplotlib')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from .metrics import reduction_percent

ROOT = Path(__file__).resolve().parents[1]


def read_csv(path):
    with open(path, newline='', encoding='utf-8') as f:
        return list(csv.DictReader(f))


def number(row, key):
    return float(row[key]) if row[key] else float('nan')


def save_csv(path, rows):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        for row in rows:
            writer.writerow({k: ('' if isinstance(v, (float, np.floating)) and not np.isfinite(v) else v)
                             for k, v in row.items()})


def run(out=ROOT/'results'):
    out = Path(out)
    figs = out/'figures'
    figs.mkdir(parents=True, exist_ok=True)
    plt.rcParams.update({'figure.dpi': 130, 'axes.spines.top': False,
                         'axes.spines.right': False, 'font.size': 10})
    summary = {'scope': 'Arithmetic from published rounded tables; not a numerical rerun',
               'doi': '10.1016/j.oceaneng.2023.116590'}
    for name, label, unit in [('water_levels', 'station', 'Maximum water elevation (m)'),
                              ('wave_heights', 'stage', 'Significant wave height (m)')]:
        rows = read_csv(ROOT/'data/published'/f'{name}.csv')
        for row in rows:
            obs = number(row, 'observed_m')
            for model, short in [('xbnh', 'nh'), ('xbsb', 'sb')]:
                err = abs(number(row, f'{model}_m')-obs)
                row[f'recomputed_abs_{short}_m'] = err
                row[f'recomputed_pct_{short}'] = 100*err/abs(obs)
                row[f'pct_delta_{short}_percentage_points'] = 100*err/abs(obs)-number(row, f'published_pct_{short}')
        save_csv(out/'tables'/f'{name}_audit.csv', rows)
        summary[name] = {}
        for short in ('nh', 'sb'):
            summary[name][short] = {
                'mean_published_pct': float(np.mean([number(r, f'published_pct_{short}') for r in rows])),
                'mean_recomputed_pct': float(np.mean([r[f'recomputed_pct_{short}'] for r in rows])),
                'max_recomputed_pct': max(r[f'recomputed_pct_{short}'] for r in rows)}
        fig, ax = plt.subplots(figsize=(8, 4.2))
        x = np.arange(len(rows))
        for j, (field, desc, color) in enumerate([('observed_m','Published observation','#333333'),
                                                 ('xbnh_m','Published XBNH','#2374ab'),
                                                 ('xbsb_m','Published XBSB','#e67e22')]):
            ax.bar(x+(j-1)*.24, [number(r,field) for r in rows], width=.23,label=desc,color=color)
        ax.set_xticks(x, [r[label] for r in rows]);ax.set_ylabel(unit)
        ax.set_title('Published values — arithmetic reconstruction, not a model rerun')
        ax.legend(frameon=False, fontsize=9);ax.grid(axis='y', alpha=.2)
        fig.tight_layout();fig.savefig(figs/f'{name}.png');plt.close(fig)

    rows = read_csv(ROOT/'data/published/dune_attenuation.csv')
    for row in rows:
        before, after = number(row, 'hs_p3_m'), number(row, 'hs_p4_m')
        row['recomputed_reduction_m'] = before-after
        row['recomputed_reduction_pct'] = float(reduction_percent(before, after))
        row['reduction_delta_m'] = before-after-number(row,'published_reduction_m')
    save_csv(out/'tables/dune_attenuation_audit.csv', rows)
    summary['attenuation_pct_from_rounded_heights'] = {
        r['stage']: r['recomputed_reduction_pct'] if np.isfinite(r['recomputed_reduction_pct']) else None for r in rows}
    fig, (ax, ax2) = plt.subplots(2,1,figsize=(8,6.4),sharex=True)
    x = np.arange(5)
    ax.plot(x, [number(r,'hs_p3_m') for r in rows], 'o-', label='P3, before dune')
    ax.plot(x, [number(r,'hs_p4_m') for r in rows], 's-', label='P4, behind dune')
    ax.set_ylabel('Published Hs (m)');ax.legend(frameon=False)
    ax.set_title('Table 10 — published results and recomputed attenuation')
    rates = [r['recomputed_reduction_pct'] for r in rows]
    ax2.bar(x, rates, color='#2374ab')
    for i, v in enumerate(rates):
        if np.isfinite(v): ax2.text(i,v+2,f'{v:.1f}%',ha='center')
    ax2.text(0,5,'not reported',ha='center',fontsize=9)
    ax2.set_ylim(0,105);ax2.set_ylabel('Recomputed reduction (%)');ax2.set_xticks(x,[r['stage'] for r in rows])
    for a in (ax,ax2): a.grid(axis='y',alpha=.2)
    fig.tight_layout();fig.savefig(figs/'dune_attenuation.png');plt.close(fig)

    rows = read_csv(ROOT/'data/published/dune_peaks.csv')
    for row in rows:
        for m, short in [('xbnh','nh'),('xbsb','sb')]:
            row[f'recomputed_signed_error_{short}_m'] = number(row,f'{m}_post_m')-number(row,'post_observed_m')
    save_csv(out/'tables/dune_peak_audit.csv', rows)
    summary['dune_peaks_signed_mean_error_m'] = {
        s: float(np.mean([r[f'recomputed_signed_error_{s}_m'] for r in rows])) for s in ('nh','sb')}
    rows = read_csv(ROOT/'data/published/breakers.csv')
    l0 = 9.81 * 9**2/(2*np.pi)
    for r in rows:
        r['deepwater_wavelength_m'] = l0
        r['recomputed_steepness'] = number(r,'hs_m')/l0
        r['breaking_depth_using_0_594_m'] = number(r,'hs_m')/.594
        r['implied_tan_beta_from_reported_iribarren'] = number(r,'published_iribarren')*np.sqrt(r['recomputed_steepness'])
    save_csv(out/'tables/breakers_audit.csv', rows)
    summary['deepwater_wavelength_tp9_m'] = l0
    (out/'summary.json').write_text(json.dumps(summary,indent=2,allow_nan=False)+'\n')
    return summary


if __name__ == '__main__':
    print(json.dumps(run(), indent=2))
