"""Run and analyse reduced 1D experiments; never label these the 2D paper run."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

import numpy as np
from netCDF4 import Dataset
from .audit import ROOT, read_csv, number, save_csv
from .metrics import significant_height, literal_paper_hs, reduction_percent


def prepare(case, mode='nonh', *, dx=2.5, smoke=False, fixed_bed=False):
    case=Path(case).resolve()
    if case.exists() and any(case.iterdir()):
        raise FileExistsError(f'Refusing to overwrite existing run: {case}')
    case.mkdir(parents=True,exist_ok=True)
    profile=np.genfromtxt(ROOT/'data/digitized/section_a_pre.csv',delimiter=',',names=True)
    boundary=np.genfromtxt(ROOT/'data/digitized/boundary_15min.csv',delimiter=',',names=True)
    nx=round(500/dx)
    if abs(nx*dx-500)>1e-8: raise ValueError('dx must divide 500 m')
    x=np.linspace(0,500,nx+1)
    z=np.interp(x,profile['x_m'],profile['z_m'])
    tstop=1800 if smoke else 21600
    if smoke:
        boundary=np.zeros(3,dtype=boundary.dtype)
        boundary['time_s']=[0,900,1800]
        boundary['hs_m']=2.03;boundary['surge_m']=4.72;boundary['tp_s']=9
    np.savetxt(case/'x.grd',x[None,:],fmt='%.6f')
    np.savetxt(case/'bed.dep',z[None,:],fmt='%.6f')
    # Explicit surrogate: erodible thickness 10 m seaward of x=260 m,
    # zero landward. Not the unknown authors' building/road mask.
    np.savetxt(case/'erodible.dep',np.where(x<260,10.,0.)[None,:],fmt='%.6f')
    np.savetxt(case/'tide.txt',np.column_stack([boundary['time_s'],boundary['surge_m']]),fmt='%.6f')
    # Hm0 Tp mainang gammajsp directional_spreading duration dtbc.
    # Upstream waveparamsnew.F90:633 ALWAYS converts JONSWAP mainang from
    # nautical "coming from", independently of thetanaut. 270 means from
    # west, propagation +x for alfa=0. thetanaut=0 applies to grid limits only.
    waves=np.column_stack([boundary['hs_m'],boundary['tp_s'],np.full(len(boundary),270.),
                           np.full(len(boundary),3.3),np.full(len(boundary),1000.),
                           np.full(len(boundary),900.),np.full(len(boundary),.5)])
    np.savetxt(case/'waves.txt',waves,fmt='%.6f')
    moving=not (smoke or fixed_bed)
    params=f'''%% REDUCED 1D EXPERIMENT, NOT THE AUTHOR'S 2D CASE
wavemodel = {mode}
swave = {0 if mode=='nonh' else 1}
nx = {nx}
ny = 0
vardx = 1
xfile = x.grd
depfile = bed.dep
posdwn = -1
alfa = 0
xori = 0
yori = 0
thetamin = -90
thetamax = 90
dtheta = 180
thetanaut = 0
single_dir = 0
tstop = {tstop}
CFL = 0.7
bedfriction = manning
bedfriccoef = 0.035
wbctype = jonstable
bcfile = waves.txt
random = 0
tideloc = 1
zs0file = tide.txt
zs0 = {boundary['surge_m'][0]:.6f}
front = {'nonh_1d' if mode=='nonh' else 'abs_1d'}
back = abs_1d
lateralwave = neumann
sedtrans = {int(moving)}
morphology = {int(moving)}
avalanching = {int(moving)}
form = vanthiel_vanrijn
D50 = 0.0002
D90 = 0.0003
morfac = 1
morstart = 600
struct = {int(moving)}
ne_layer = erodible.dep
gamma = 0.46
gamma2 = 0.34
nhbreaker = 1
break = roelvink1
outputformat = netcdf
tstart = 0
tintg = 1
nglobalvar = 4
zs
zb
H
hh
'''
    (case/'params.txt').write_text(params)
    manifest={
        'scope':'Reduced 1D experiment using raster-digitized inputs; NOT full paper reproduction',
        'mode':mode,'dx_m':dx,'nx':nx,'ny':0,'tstop_s':tstop,
        'morphology':moving,'smoke':smoke,
        'paper_settings':['Manning n=0.035','CFL=0.7','Tp=9 s','gamma=0.46','gamma2=0.34','vanthiel_vanrijn'],
        'assumptions':{'grid':'uniform 1D, rather than original 2D variable grid',
                       'jonswap_gamma':3.3,'directional_spreading':1000,
                       'D50_m':.0002,'D90_m':.0003,'morfac':1,'morstart_s':600,
                       'erodible_thickness_m':'10 where x<260, 0 elsewhere',
                       'rear_boundary':'abs_1d','phase_seed':'upstream random=0, deterministic seed=100',
                       'jonswap_mainang_deg_nautical':270,
                       'duration':'6 elapsed hours, Fig.6 14:00-20:00; conflicting prose says 7 hours'},
        'input_sha256':{n:hashlib.sha256((case/n).read_bytes()).hexdigest() for n in
                        ('x.grd','bed.dep','erodible.dep','tide.txt','waves.txt','params.txt')}}
    (case/'case.json').write_text(json.dumps(manifest,indent=2)+'\n')
    return manifest


def execute(case, binary):
    case=Path(case).resolve();binary=Path(binary).resolve()
    binary_hash=hashlib.sha256(binary.read_bytes()).hexdigest()
    start=time.monotonic()
    with (case/'stdout.log').open('w') as log:
        p=subprocess.run([str(binary)],cwd=case,stdout=log,stderr=subprocess.STDOUT)
    if p.returncode:
        raise RuntimeError(f'XBeach exit {p.returncode}; see {case}/stdout.log')
    return validate_output(case,wall_seconds=time.monotonic()-start,binary_sha256=binary_hash)


def validate_output(case, *, wall_seconds=None, binary_sha256=None):
    """Validate completed output, allowing upstream remdryoutput dry masks.

    Source ncoutput.F90 calls postprocessvar_r2(s%wetz,...,dFill,...).
    Thus a matched zs/hh mask is expected for dry cells, not instability.
    """
    case=Path(case).resolve()
    manifest=json.loads((case/'case.json').read_text())
    output=case/'xboutput.nc'
    if not output.exists():
        raise RuntimeError(f'No numerical output; see {case}/stdout.log (Fortran STOP can exit 0)')
    with Dataset(output) as ds:
        t=np.asarray(ds['globaltime'][:])
        if not len(t) or not np.isclose(t[-1],manifest['tstop_s'],atol=1e-3,rtol=0):
            raise RuntimeError(f'Incomplete run: final output {t[-1] if len(t) else None}, expected {manifest["tstop_s"]}')
        masks={}
        for key in ('zs','zb','hh'):
            a=np.ma.asarray(ds[key][:])
            masks[key]=np.ma.getmaskarray(a)
            if (key=='zb' and masks[key].any()) or not np.isfinite(a.compressed()).all():
                raise RuntimeError(f'Nonfinite/missing numerical output: {key}')
        if not np.array_equal(masks['zs'],masks['hh']):
            raise RuntimeError('Surface/depth masks differ; cannot identify dry cells safely')
        wet_zs=np.ma.asarray(ds['zs'][:]).compressed()
        if not len(wet_zs) or np.max(np.abs(wet_zs))>100:
            raise RuntimeError('Unphysical water elevation above 100 m; inspect model stability')
    receipt={'status':'completed_and_validated','wall_seconds':wall_seconds,
             'final_time_s':float(t[-1]),'output_samples':len(t),
             'dry_masked_surface_values':int(masks['zs'].sum()),
             'dry_policy':'Native matching zs/hh masks retained; Hs omitted if any sample in window is dry',
             'binary_sha256':binary_sha256}
    (case/'run_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    return receipt


def arrays(case):
    with Dataset(Path(case)/'xboutput.nc') as ds:
        t=np.array(ds['globaltime'][:])
        x=np.array(ds['globalx'][:]).reshape(-1)
        # ny=0 yields exactly one row; reject other geometries rather than
        # flattening their alongshore dimension into a fictitious transect.
        if ds['zs'].shape[1]!=1:
            raise ValueError('Expected a single-row 1D output')
        a={key:np.ma.asarray(ds[key][:]).filled(np.nan)[:,0,:] for key in ('zs','zb','hh','H')}
    if not np.allclose(np.diff(t),1,rtol=0,atol=1e-4):
        raise ValueError('Statistics require uniform 1 Hz output')
    return t,x,a


def analyse(case,out=None):
    case=Path(case);manifest=json.loads((case/'case.json').read_text())
    t,x,a=arrays(case)
    if out is None: out=ROOT/'results'/case.name
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    if manifest['smoke']:
        windows=[('peak_smoke',900,1800)]
    else:
        # Approximate marker centres read from Fig 6(a), 2x raster pixels.
        centres=(np.array([588,616,659,728,756])-288)*21600/624
        windows=[(f'T{i+1}',float(c-450),float(c+450)) for i,c in enumerate(centres)]
    results=[];profiles=[]
    paper={r['stage']:r for r in read_csv(ROOT/'data/published/dune_attenuation.csv')}
    for stage,t0,t1 in windows:
        ix=(t>=t0)&(t<t1)
        if ix.sum()!=900:
            raise ValueError(f'Expected 900 one-second samples; got {ix.sum()} for {stage}')
        hs=np.full(len(x),np.nan)
        wet=np.isfinite(a['zs'][ix]).all(axis=0) & np.isfinite(a['hh'][ix]).all(axis=0)
        if manifest['mode']=='nonh':
            if wet.any(): hs[wet]=significant_height(a['zs'][ix][:,wet],linear_detrend=True)
        else:
            # H is RMS short-wave height in XBeach. This conversion follows
            # Eq.8, not statistics of the surfbeat zs (which omit short waves).
            valid=wet & np.isfinite(a['H'][ix]).all(axis=0)
            hs[valid]=np.mean(a['H'][ix][:,valid],axis=0)*np.sqrt(2)
        dry=np.mean(~np.isfinite(a['hh'][ix]) | (a['hh'][ix]<=.01),axis=0)
        i3=int(np.argmin(abs(x-160)));i4=int(np.argmin(abs(x-240)))
        row={'stage':stage,'window_start_s':t0,'window_end_s':t1,
             'mode':manifest['mode'],'dx_m':manifest['dx_m'],
             'p3_x_m':x[i3],'p4_x_m':x[i4],
             'hs_p3_m':hs[i3],'hs_p4_m':hs[i4],
             'reduction_pct':float(reduction_percent(hs[i3],hs[i4])),
             'p3_dry_fraction':dry[i3],'p4_dry_fraction':dry[i4],
             'dune_top_m':float(np.max(np.mean(a['zb'][ix],axis=0)[(x>=150)&(x<=250)])),
             'published_reduction_pct':number(paper[stage],'published_reduction_pct') if stage in paper else np.nan}
        if manifest['mode']=='nonh':
            row['literal_eq6_7_at_p3_not_hs'] = float(literal_paper_hs(a['zs'][ix,i3])) if wet[i3] else np.nan
        results.append(row)
        surface=a['zs'][ix];count=np.isfinite(surface).sum(axis=0)
        mean_surface=np.full(len(x),np.nan)
        np.divide(np.nansum(surface,axis=0),count,out=mean_surface,where=count>0)
        profiles.append({'hs':hs,'surge':mean_surface,
                         'zb':np.mean(a['zb'][ix],axis=0),'dry_fraction':dry})
    save_csv(out/'stage_statistics.csv',results)
    np.savez_compressed(out/'profiles.npz',x=x,stages=[r['stage'] for r in results],
                        hs=[r['hs'] for r in profiles],zb=[r['zb'] for r in profiles],
                        surge=[r['surge'] for r in profiles],
                        dry_fraction=[r['dry_fraction'] for r in profiles],
                        initial_bed=a['zb'][0],final_bed=a['zb'][-1])
    (out/'case.json').write_text((case/'case.json').read_text())
    (out/'run_receipt.json').write_text((case/'run_receipt.json').read_text())
    os.environ.setdefault('MPLCONFIGDIR','/tmp/beach-matplotlib')
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig,axes=plt.subplots(len(results),1,figsize=(10,2.7*len(results)),squeeze=False)
    for i,(row,p) in enumerate(zip(results,profiles)):
        ax=axes[i,0];ax.plot(x,p['hs'],color='#2374ab',label='Computed Hs')
        ax.set_ylabel('Hs (m)',color='#2374ab');ax.set_ylim(0,3)
        ax2=ax.twinx();ax2.plot(x,p['zb'],color='#997340',label='Computed bed')
        ax2.plot(x,p['surge'],color='#62959f',alpha=.7,label='Mean wet surface')
        ax2.set_ylabel('Elevation (m)');ax2.set_ylim(-3,7)
        for xx,label in [(160,'P3'),(240,'P4')]:
            ax.axvline(xx,color='gray',ls=':',lw=.8);ax.text(xx,2.7,label,ha='center')
        ax.set_title(f'{row["stage"]} | 1D {manifest["mode"]}, digitized inputs | NOT the original 2D run',fontsize=10)
        if i==0:
            ax.legend(loc='upper left',frameon=False,fontsize=8)
            ax2.legend(loc='upper right',frameon=False,fontsize=8)
    axes[-1,0].set_xlabel('Distance along approximate section A (m)')
    fig.tight_layout();fig.savefig(out/'profiles.png',dpi=140);plt.close(fig)
    return results


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--case',required=True);p.add_argument('--mode',choices=['nonh','surfbeat'],default='nonh')
    p.add_argument('--dx',type=float,default=2.5);p.add_argument('--smoke',action='store_true')
    p.add_argument('--fixed-bed',action='store_true')
    p.add_argument('--binary',default=ROOT/'.tools/bin/xbeach')
    p.add_argument('--analyse-only',action='store_true')
    a=p.parse_args()
    if not a.analyse_only:
        prepare(a.case,a.mode,dx=a.dx,smoke=a.smoke,fixed_bed=a.fixed_bed)
        print(json.dumps(execute(a.case,a.binary),indent=2),flush=True)
    print(json.dumps(analyse(a.case),indent=2,default=float),flush=True)


if __name__=='__main__': main()
