"""Transparent partial reproduction of Ma et al. (2024)."""
