"""Wave statistics with explicit conventions and no silent gap filling."""
import numpy as np
from scipy.signal import detrend


def significant_height(eta, *, linear_detrend=False, axis=0):
    """Hm0 = 4 sqrt(mean(eta'^2)); population variance, metres in/out.

    Use a single finite, uniformly sampled window. Linear detrending is an
    explicit option for a changing surge, not an undocumented filtering step.
    This is a variance estimate, not a zero-crossing H1/3 estimate.
    """
    a = np.asarray(eta, dtype=float)
    if a.ndim == 0 or a.shape[axis] < 2 or not np.isfinite(a).all():
        raise ValueError('Need at least two finite samples per window')
    residual = detrend(a, axis=axis, type='linear' if linear_detrend else 'constant')
    return 4 * np.sqrt(np.mean(residual**2, axis=axis))


def literal_paper_hs(eta, *, axis=0):
    """Eq. 6/7 literally: 4 sqrt(mean(abs(diff(eta)))).

    Diagnostic only: the square root has units sqrt(m), not m, and depends on
    sampling interval. Not a physically valid Hm0 estimator.
    """
    a = np.asarray(eta, dtype=float)
    if a.ndim == 0 or a.shape[axis] < 2 or not np.isfinite(a).all():
        raise ValueError('Need at least two finite samples per window')
    return 4 * np.sqrt(np.mean(np.abs(np.diff(a, axis=axis)), axis=axis))


def reduction_percent(before, after):
    b, a = np.broadcast_arrays(np.asarray(before, float), np.asarray(after, float))
    out = np.full(b.shape, np.nan)
    np.divide(100 * (b-a), b, out=out, where=np.isfinite(b) & np.isfinite(a) & (b > 0))
    return out


def brier_skill(pre, observed_post, simulated_post):
    """Eq. 9. BSS may be negative; never clip it to [0, 1]."""
    pre, obs, sim = np.broadcast_arrays(pre, observed_post, simulated_post)
    if not all(np.isfinite(v).all() for v in (pre, obs, sim)):
        raise ValueError('BSS requires aligned finite profiles')
    denominator = np.sum((obs-pre)**2)
    if denominator == 0:
        raise ValueError('BSS undefined when observed bed does not change')
    return 1 - np.sum((obs-sim)**2)/denominator


def jonswap(frequency_hz, hs_m, tp_s, gamma=3.3):
    """One-sided JONSWAP normalized numerically so integral S df = Hs²/16.

    gamma=3.3 is an explicit demonstration assumption, not a paper value.
    """
    f = np.asarray(frequency_hz, float)
    if f.ndim != 1 or len(f) < 3 or np.any(f < 0) or np.any(np.diff(f) <= 0):
        raise ValueError('Frequencies must be nonnegative and strictly increasing')
    if hs_m <= 0 or tp_s <= 0 or gamma <= 0:
        raise ValueError('Hs, Tp and gamma must be positive')
    fp = 1/tp_s
    s = np.zeros_like(f)
    positive = f > 0
    q = f[positive]
    sigma = np.where(q <= fp, 0.07, 0.09)
    r = np.exp(-((q-fp)**2)/(2*sigma**2*fp**2))
    s[positive] = q**-5 * np.exp(-1.25*(fp/q)**4) * gamma**r
    integral = np.trapezoid(s, f)
    if integral <= 0:
        raise ValueError('Frequency range does not resolve spectrum')
    return s * (hs_m/4)**2/integral
