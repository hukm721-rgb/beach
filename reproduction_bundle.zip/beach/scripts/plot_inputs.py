#!/usr/bin/env python3
import os
os.environ.setdefault('MPLCONFIGDIR','/tmp/beach-matplotlib')
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from beach_repro.metrics import significant_height,literal_paper_hs,jonswap

root=Path(__file__).resolve().parents[1]
out=root/'results/figures';out.mkdir(parents=True,exist_ok=True)
b=np.genfromtxt(root/'data/digitized/boundary_15min.csv',delimiter=',',names=True)
z=np.genfromtxt(root/'data/digitized/section_a_pre.csv',delimiter=',',names=True)
fig,axes=plt.subplots(3,1,figsize=(9,8))
axes[0].plot(b['time_s']/3600,b['hs_m'],'o-',ms=3,label='Raster-digitized Fig. 6(a)')
axes[0].set_ylabel('Boundary Hs (m)')
axes[1].plot(b['time_s']/3600,b['surge_m'],'o-',ms=3,label='Raster-digitized Fig. 6(b)')
axes[1].set_ylabel('Boundary surge (m)');axes[1].set_xlabel('Elapsed hours from 14:00 UTC, 10 Oct 2018')
axes[2].plot(z['x_m'],z['z_m'],color='#997340',label='Raster-digitized Fig. 10 (pre-storm)')
axes[2].set_ylabel('Bed elevation (m)');axes[2].set_xlabel('Distance along section A (m)')
for xx,label in [(160,'P3 ~160 m'),(240,'P4 ~240 m')]:
    axes[2].axvline(xx,ls=':',color='gray');axes[2].text(xx,0,label,rotation=90,ha='right')
for ax in axes:
    ax.legend(frameon=False);ax.grid(alpha=.2)
fig.suptitle('Approximate inputs from raster figures — not author source data')
fig.tight_layout();fig.savefig(out/'digitized_inputs.png',dpi=150);plt.close(fig)

fig,(ax,ax2)=plt.subplots(1,2,figsize=(10,4))
dts=np.array([.1,.2,.5,1.])
exact=[];literal=[]
for dt in dts:
    t=np.arange(0,900,dt);eta=4.72+.5*np.sin(2*np.pi*t/9)
    exact.append(significant_height(eta));literal.append(literal_paper_hs(eta))
ax.plot(dts,exact,'o-',label='4 std(eta), m')
ax.plot(dts,literal,'s--',label='Literal Eq. 6/7, sqrt(m)')
ax.set_xlabel('Sampling interval (s)');ax.set_ylabel('Estimator value (different units!)')
ax.set_title('Formula ambiguity: same 9 s sinusoid');ax.legend(fontsize=8,frameon=False)
f=np.linspace(0,.6,6001)
ax2.plot(f,jonswap(f,2.03,9));ax2.set_xlim(0,.4)
ax2.set_xlabel('Frequency (Hz)');ax2.set_ylabel('S(f) (m²/Hz)')
ax2.set_title('Assumed JONSWAP: Hs=2.03 m, Tp=9 s, gamma=3.3')
fig.tight_layout();fig.savefig(out/'wave_statistics_and_spectrum.png',dpi=150);plt.close(fig)
