#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
export MPLCONFIGDIR=/tmp/beach-matplotlib
export XDG_CACHE_HOME=/tmp/beach-cache
export PYTHONPATH="$ROOT${PYTHONPATH:+:$PYTHONPATH}"
PYTHON="${BEACH_PYTHON:-$ROOT/.venv/bin/python}"
case "${1:-audit}" in
  audit|numerical) ;;
  *) echo 'Usage: bash scripts/reproduce.sh [audit|numerical]' >&2; exit 2 ;;
esac
"$PYTHON" -m beach_repro.audit
"$PYTHON" scripts/plot_inputs.py
"$PYTHON" -m pytest -q
if [[ "${1:-audit}" == numerical ]]; then
  # Each task is already isolated. Use the existing checkout; do not create
  # worktrees. Keep previous run directories and never overwrite their files.
  mkdir -p "$ROOT/runs"
  RUN_ROOT="$(mktemp -d "$ROOT/runs/reproduction.XXXXXX")"
  "$PYTHON" -m beach_repro.xbeach --case "$RUN_ROOT/smoke_nh" --smoke
  "$PYTHON" -m beach_repro.xbeach --case "$RUN_ROOT/storm_nh" --mode nonh
  "$PYTHON" -m beach_repro.xbeach --case "$RUN_ROOT/storm_sb" --mode surfbeat
  echo "Raw run files: $RUN_ROOT"
fi
