#!/usr/bin/env python3
"""Extract approximate curves from the supplied raster figures, never targets.

Pixel calibration is deliberately recorded. PNG rendering is not OCR and has
no access to the authors' numerical source arrays. Use only this exact PDF.
"""
import argparse
import csv
import hashlib
import json
from pathlib import Path

import fitz
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
EXPECTED_PDF_SHA256 = 'a10a986d51023c0a7f6f99c476fc5c4bb65bdf51fbe01851c2fa35efc8ecdead'


def write(path, header, data):
    with path.open('w', newline='') as f:
        w = csv.writer(f);w.writerow(header);w.writerows(data)


def pixels(page):
    p = page.get_pixmap(matrix=fitz.Matrix(2,2), alpha=False)
    return np.frombuffer(p.samples,dtype=np.uint8).reshape(p.height,p.width,3)


def trace(rgb, rect, color, *, exclude=()):
    x0,y0,x1,y1=rect
    a=rgb[y0:y1+1,x0:x1+1].astype(float)
    if color=='red':
        mask=(a[:,:,0]>180)&(a[:,:,1]<130)&(a[:,:,2]<130)
    else:
        mask=(a[:,:,2]>160)&(a[:,:,0]<130)&(a[:,:,1]<150)
    for ex in exclude:
        ex0,ey0,ex1,ey1=ex
        mask[max(0,ey0-y0):ey1-y0+1,max(0,ex0-x0):ex1-x0+1]=False
    xs=[];ys=[]
    for i in range(mask.shape[1]):
        yy=np.flatnonzero(mask[:,i])
        if len(yy): xs.append(x0+i);ys.append(y0+np.median(yy))
    return np.array(xs),np.array(ys)


def main(pdf):
    pdf=Path(pdf)
    digest=hashlib.sha256(pdf.read_bytes()).hexdigest()
    if digest != EXPECTED_PDF_SHA256:
        raise ValueError('PDF hash differs from the calibrated attachment; recalibrate pixel axes first')
    doc=fitz.open(pdf)
    d=ROOT/'data/digitized';d.mkdir(parents=True,exist_ok=True)
    rgb=pixels(doc[11])
    xp,yp=trace(rgb,(119,654,562,874),'red',exclude=[(275,827,554,842)])
    # Fig 10: x=0..500 m at 119..562 px; z=4..-2 m at 669..858 px.
    x=(xp-119)*500/(562-119)
    z=4+(yp-669)*(-6)/(858-669)
    xout=np.arange(0,500.0001,2.5)
    if np.max(np.diff(x))>8:
        raise ValueError('Unexpected gap in bed tracing; inspect original')
    write(d/'section_a_pre.csv',['x_m','z_m'],zip(xout,np.interp(xout,x,z)))
    rgb=pixels(doc[7])
    t=np.arange(0,21600+1,900)
    curves=[]
    for rect,y0,y1,v0,v1 in [((289,131,911,340),131,340,2.5,0),
                             ((289,421,911,630),421,630,6,1)]:
        xp,yp=trace(rgb,rect,'blue',exclude=[(738,140,908,190),(738,430,908,480)])
        tt=(xp-288)*21600/(912-288)
        vv=v0+(yp-y0)*(v1-v0)/(y1-y0)
        curves.append(np.interp(t,tt,vv))
    write(d/'boundary_15min.csv',['time_s','hs_m','surge_m','tp_s'],
          zip(t,curves[0],curves[1],np.full(len(t),9.)))
    metadata={
        'source_pdf_sha256':digest,'doi':'10.1016/j.oceaneng.2023.116590',
        'method':'2x PDF raster rendering, color-threshold median trace and linear interpolation',
        'not_author_data':True,
        'section_a_pre':{'figure':10,'pdf_page':12,'x_pixels':[119,562],
                         'x_metres':[0,500],'z_pixels':[669,858],'z_metres':[4,-2],
                         'estimated_tracing_uncertainty_pixels':2,
                         'point_positions_approximate_m':{'P1':0,'P2':70,'P3':160,'P4':240}},
        'boundary':{'figure':6,'pdf_page':8,'x_pixels':[288,912],
                    'time_seconds':[0,21600],
                    'utc_endpoints':['2018-10-10T14:00:00Z','2018-10-10T20:00:00Z'],
                    'hs_y_pixels':[131,340],'hs_metres':[2.5,0],
                    'surge_y_pixels':[421,630],'surge_metres':[6,1],
                    'note':'Figure labels 1..7 are plotted hours, not 7 elapsed hours; 14 to 20 UTC is 6 hours. Stage marker positions differ slightly between panels.'}}
    (d/'provenance.json').write_text(json.dumps(metadata,indent=2)+'\n')
    print(json.dumps({'pdf_sha256':digest,'bed_nodes':len(xout),'boundary_rows':len(t)},indent=2))


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('pdf')
    main(p.parse_args().pdf)
