#!/usr/bin/env python3
"""Plot independently computed reduced runs alongside published table values."""
import os
os.environ.setdefault('MPLCONFIGDIR','/tmp/beach-matplotlib')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from beach_repro.audit import ROOT,read_csv,number,save_csv


def main():
    paper=read_csv(ROOT/'data/published/dune_attenuation.csv')
    nh=read_csv(ROOT/'results/storm_nh/stage_statistics.csv')
    sb=read_csv(ROOT/'results/storm_sb/stage_statistics.csv')
    rows=[]
    for p,n,s in zip(paper,nh,sb,strict=True):
        assert p['stage']==n['stage']==s['stage']
        rows.append({'stage':p['stage'],
                     'published_reduction_pct':number(p,'published_reduction_pct'),
                     'nh_1d_reduction_pct':number(n,'reduction_pct'),
                     'sb_1d_reduction_pct':number(s,'reduction_pct'),
                     'nh_hs_p3_m':number(n,'hs_p3_m'),'nh_hs_p4_m':number(n,'hs_p4_m'),
                     'sb_hs_p3_m':number(s,'hs_p3_m'),'sb_hs_p4_m':number(s,'hs_p4_m')})
    save_csv(ROOT/'results/tables/reduced_storm_comparison.csv',rows)
    fig,axes=plt.subplots(2,1,figsize=(10,7.5),sharex=True)
    x=np.arange(5)
    axes[0].plot(x,[number(p,'published_reduction_pct') for p in paper],'o--',color='#444444',label='Published Table 10')
    axes[0].plot(x,[number(n,'reduction_pct') for n in nh],'s-',color='#2374ab',label='Computed reduced 1D XBNH')
    axes[0].plot(x,[number(s,'reduction_pct') for s in sb],'^-',color='#e67e22',label='Computed reduced 1D XBSB')
    axes[0].set_ylabel('Hs reduction, P3 to P4 (%)')
    axes[0].set_title('Different inputs and geometry: diagnostic comparison, not a validation')
    axes[0].legend(frameon=False,fontsize=9)
    for series,short,linestyle,color in [(nh,'XBNH','-','#2374ab'),(sb,'XBSB','--','#e67e22')]:
        for key,marker,desc in [('hs_p3_m','o','P3'),('hs_p4_m','s','P4')]:
            axes[1].plot(x,[number(v,key) for v in series],marker=marker,ls=linestyle,color=color,label=f'1D {short} {desc}')
    axes[1].set_ylabel('Computed Hs (m)');axes[1].legend(frameon=False,ncol=2,fontsize=9)
    axes[1].set_xticks(x,[p['stage'] for p in paper]);axes[1].set_xlabel('Approximate stage windows digitized from Fig. 6')
    for ax in axes: ax.grid(alpha=.2)
    fig.tight_layout();fig.savefig(ROOT/'results/figures/reduced_storm_comparison.png',dpi=150);plt.close(fig)


if __name__=='__main__': main()
