#!/usr/bin/env bash
# Source this file. Tools are extracted locally; no root installation needed.
BEACH_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BEACH_SYSROOT="$BEACH_ROOT/.tools/sysroot"
export PATH="$BEACH_SYSROOT/usr/bin:$PATH"
export autom4te_perllibdir="$BEACH_SYSROOT/usr/share/autoconf"
export AC_MACRODIR="$BEACH_SYSROOT/usr/share/autoconf"
export AUTOM4TE_CFG="$BEACH_SYSROOT/usr/share/autoconf/autom4te.cfg"
export AUTOMAKE_LIBDIR="$BEACH_SYSROOT/usr/share/automake-1.17"
export ACLOCAL_PATH="$BEACH_SYSROOT/usr/share/aclocal"
export ACLOCAL_AUTOMAKE_DIR="$BEACH_SYSROOT/usr/share/aclocal-1.17"
export LIBTOOLIZE_PKGAUXDIR="$BEACH_SYSROOT/usr/share/libtool/build-aux"
export LIBTOOLIZE_PKGMACRODIR="$BEACH_SYSROOT/usr/share/aclocal"
export PERL5LIB="$BEACH_SYSROOT/usr/share/automake-1.17"
export AUTOM4TE="$BEACH_SYSROOT/usr/bin/autom4te"
export AUTOCONF="$BEACH_SYSROOT/usr/bin/autoconf"
export AUTOHEADER="$BEACH_SYSROOT/usr/bin/autoheader"
export AUTOMAKE="$BEACH_SYSROOT/usr/bin/automake"
export ACLOCAL="$BEACH_SYSROOT/usr/bin/aclocal"
export M4="$BEACH_SYSROOT/usr/bin/m4"
export MPLCONFIGDIR=/tmp/beach-matplotlib
export XDG_CACHE_HOME=/tmp/beach-cache
