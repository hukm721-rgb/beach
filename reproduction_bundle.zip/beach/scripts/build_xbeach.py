#!/usr/bin/env python3
"""Serial, dependency-ordered build of the pinned upstream XBeach mirror.

Uses upstream's Mako generator and unmodified numerical sources. Avoids the
legacy autotools toolchain by deriving the upstream Makefile's source list.
Requires gfortran, gcc and NetCDF Fortran development files.
"""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
COMMIT = '6f1dd9626f57cdc0a5b306f5975ba4ce0d7a5a29'
URL = 'https://github.com/openearth/xbeach.git'


def call(args, **kwargs):
    return subprocess.run(list(map(str,args)),check=True,**kwargs)


def build(source, fc, local_sysroot=None, link_only=False):
    source=Path(source).resolve()
    fc=str(Path(fc).resolve())
    head=subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip()
    if head!=COMMIT:
        raise ValueError(f'Expected pinned solver {COMMIT}; got {head}')
    # Fail rather than silently building edited numerical sources.
    changed=subprocess.check_output(['git','-C',str(source),'diff','--name-only'],text=True).splitlines()
    if any(p.lower().endswith(('.f90','.inp','.ind')) for p in changed):
        raise ValueError('Numerical source modifications detected')
    lib=source/'src/xbeachlibrary'
    work=ROOT/'.tools/xbeach-build';work.mkdir(parents=True,exist_ok=True)
    call([sys.executable,source/'scripts/generate.py'],cwd=source)
    (lib/'version.dat').write_text(
        f"Build_Revision = '{head}'\nBuild_URL = '{URL}'\nBuild_Date = 'reproduction pinned build'\n")
    flags=['-O2','-cpp','-ffree-line-length-none','-fallow-argument-mismatch',
           '-DUSENETCDF','-I'+str(lib),'-I'+str(work),'-J'+str(work)]
    # No LTO objects are produced; the minimal cloud GCC distribution lacks
    # liblto_plugin. Reuse the host GCC runtime/startup objects when linking.
    ld=['-fno-use-linker-plugin']
    if local_sysroot:
        sysroot=Path(local_sysroot).resolve()
        flags+=['-I'+str(sysroot/'usr/include')]
        ld+=['-L'+str(sysroot/'usr/lib/x86_64-linux-gnu'),
             '-L'+str(sysroot/'usr/lib/gcc/x86_64-linux-gnu/14'),
             '-B/usr/lib/gcc/x86_64-linux-gnu/14/',
             '-Wl,-rpath,'+str(sysroot/'usr/lib/x86_64-linux-gnu')]
    else:
        flags+=subprocess.check_output(['nf-config','--fflags'],text=True).split()
        ld+=subprocess.check_output(['nf-config','--flibs'],text=True).split()
    ld+=['-lnetcdff','-lnetcdf']
    make=(lib/'Makefile.am').read_text()
    block=make.split('libxbeach_la_SOURCES=',1)[1].split('BUILT_SOURCES',1)[0]
    names=re.findall(r'\b[\w]+\.[Ff]90\b',block)
    sources=[lib/n for n in names]+[source/'src/xbeach/input.F90',source/'src/xbeach/xbeach.F90']
    # An unused C metadata type has nonstandard multi-character BIND(C)
    # fields. Remove its C binding in a BUILD COPY only; numerical routines,
    # the actually used carraytype, and the upstream checkout stay unchanged.
    compat=work/'mnemoniciso.F90'
    raw=(lib/'mnemoniciso.F90').read_text()
    assert raw.count('type, bind(c) :: b_arraytype')==1
    compat.write_text(raw.replace('type, bind(c) :: b_arraytype','type :: b_arraytype'))
    sources=[compat if p.name=='mnemoniciso.F90' else p for p in sources]
    providers={}; deps={}
    for p in sources:
        result=subprocess.check_output([fc,*flags,'-E',str(p)],encoding='latin-1',cwd=work)
        for name in re.findall(r'^\s*module\s+(?!procedure\b|function\b|subroutine\b)(\w+)',result,re.I|re.M):
            providers[name.lower()]=p
        deps[p]=set(s.lower() for s in re.findall(r'^\s*use\s+(?:::)?\s*(\w+)',result,re.I|re.M))
    compiled=set();objects=[]
    while len(compiled)<len(sources):
        available=[p for p in sources if p not in compiled and
                   all(providers.get(n) in compiled or n not in providers or providers[n]==p for n in deps[p])]
        if not available:
            raise RuntimeError('Unresolved or circular Fortran module dependencies')
        for p in available:
            obj=work/(p.stem+'.o')
            print('Compiling',p.name,flush=True)
            if link_only:
                if not obj.exists(): raise FileNotFoundError(obj)
            else:
                call([fc,*flags,'-c',p,'-o',obj],cwd=work)
            compiled.add(p);objects.append(obj)
    binary=ROOT/'.tools/bin/xbeach';binary.parent.mkdir(parents=True,exist_ok=True)
    pending=binary.with_suffix('.pending')
    call([fc,*objects,*ld,'-o',pending],cwd=work)
    os.replace(pending,binary)
    meta={'url':URL,'commit':head,'source_date':'2018-06-25',
          'paper_version_unknown':True,'compiler':subprocess.check_output([fc,'--version'],text=True).splitlines()[0],
          'compile_flags':flags,'built_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),
          'build_method':'upstream generator + dependency ordered serial gfortran; equations unchanged',
          'compatibility_patch':'BUILD COPY mnemoniciso.F90: remove BIND(C) only from unused b_arraytype metadata type',
          'warning':'Upstream public mirror predates the paper. Reduced-model sensitivity experiment only.'}
    (ROOT/'results').mkdir(exist_ok=True)
    (ROOT/'results/solver_build.json').write_text(json.dumps(meta,indent=2)+'\n')
    print(binary)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source',default=ROOT/'.deps/xbeach')
    p.add_argument('--fc',default=shutil.which('gfortran'))
    p.add_argument('--sysroot')
    p.add_argument('--link-only',action='store_true',help='Reuse objects from a just-completed compile; do not use after source or flag changes')
    a=p.parse_args()
    if not a.fc: p.error('Fortran compiler not found')
    build(a.source,a.fc,a.sysroot,a.link_only)
