#!/usr/bin/env python3
"""Bundle portable scripts, small data and results; exclude PDF and tools."""
import hashlib
import json
from pathlib import Path
import zipfile

ROOT=Path(__file__).resolve().parents[1]


def main():
    for name in ('storm_nh','storm_sb'):
        receipt=json.loads((ROOT/'results'/name/'run_receipt.json').read_text())
        if receipt['status']!='completed_and_validated' or receipt['final_time_s']!=21600:
            raise RuntimeError('Cannot package an incomplete numerical result')
    candidates=[ROOT/'README.md',ROOT/'requirements.txt',ROOT/'.gitignore']
    for directory in ('beach_repro','configs','data','reports','results','scripts','tests'):
        candidates.extend(p for p in (ROOT/directory).rglob('*')
                          if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc')
    files=sorted(set(candidates))
    sums={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files
          if p.name!='bundle_manifest.json'}
    manifest=ROOT/'results/bundle_manifest.json'
    manifest.write_text(json.dumps({'files_sha256':sums,
                                   'exclusions':'original PDF, extracted pages, raw large NetCDF runs, compiler/dependencies and upstream source'},indent=2)+'\n')
    if manifest not in files: files.append(manifest)
    target=ROOT/'reproduction_bundle.zip'
    with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in files: z.write(p,Path('beach')/p.relative_to(ROOT))
    with zipfile.ZipFile(target) as z:
        if z.testzip() is not None: raise RuntimeError('Corrupt bundle')
    print(json.dumps({'path':str(target),'files':len(files),'size_bytes':target.stat().st_size},indent=2))


if __name__=='__main__': main()
