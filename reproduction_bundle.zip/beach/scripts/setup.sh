#!/usr/bin/env bash
# Debian 13 / amd64, Python 3.12+, GCC 14 runtime/startup files already present.
# All installations stay inside this checkout; HTTPS/proxy/TLS are preserved.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
python3 -m venv --system-site-packages .venv
.venv/bin/python -m pip install -r requirements.txt
mkdir -p .tools/apt/lists/partial .tools/apt/cache/archives/partial .tools/debs .tools/sysroot .deps
printf '%s\n' 'deb [signed-by=/usr/share/keyrings/debian-archive-keyring.gpg] https://deb.debian.org/debian trixie main' > .tools/debian.list
APT=(/usr/bin/apt-get -o "Dir::State::lists=$ROOT/.tools/apt/lists"
  -o "Dir::Cache=$ROOT/.tools/apt/cache"
  -o "Dir::Etc::sourcelist=$ROOT/.tools/debian.list" -o 'Dir::Etc::sourceparts=-')
"${APT[@]}" update
(
  cd .tools/debs
  "${APT[@]}" download gfortran-14=14.2.0-19 gfortran-14-x86-64-linux-gnu=14.2.0-19 \
    libgfortran-14-dev=14.2.0-19 libnetcdf-dev=1:4.9.3-1 libnetcdf22=1:4.9.3-1 \
    libnetcdff-dev=4.6.0+really4.5.4+ds-3+b4 libnetcdff7=4.6.0+really4.5.4+ds-3+b4
)
# APT verifies archive checksums against Debian-signed metadata before unpacking.
for archive in .tools/debs/*.deb; do dpkg-deb -x "$archive" .tools/sysroot; done
SOURCE="${XBEACH_SOURCE:-$ROOT/.deps/xbeach}"
if [[ ! -e "$SOURCE" ]]; then
  git clone https://github.com/openearth/xbeach.git "$SOURCE"
  git -C "$SOURCE" checkout --detach 6f1dd9626f57cdc0a5b306f5975ba4ce0d7a5a29
fi
# build_xbeach.py refuses a different commit or modified numerical sources.
.venv/bin/python scripts/build_xbeach.py --source "$SOURCE" \
  --fc "$ROOT/.tools/sysroot/usr/bin/gfortran-14" --sysroot "$ROOT/.tools/sysroot"
echo 'Setup complete. Run: bash scripts/reproduce.sh numerical'
