#!/usr/bin/env python3
"""Validate explicitly supplied author inputs before attempting full 2D runs.

No files are manufactured or imputed. Exits nonzero when required inputs are
missing. This verifies data shape, not whether a case reproduces the paper.
"""
import argparse
import json
from pathlib import Path
import numpy as np


def validate(folder):
    root=Path(folder)
    path=root/'manifest.json'
    if not path.exists():
        raise ValueError('Missing author manifest.json; see configs/author_manifest.example.json')
    m=json.loads(path.read_text())
    if not m.get('solver_version') or str(m['solver_version']).startswith('REQUIRED'):
        raise ValueError('Exact author solver version/revision is required')
    def file(key):
        if not m.get(key): raise ValueError(f'Missing manifest entry {key}')
        p=(root/m[key]).resolve()
        if not p.is_relative_to(root.resolve()): raise ValueError(f'File escapes input folder: {key}')
        if not p.is_file(): raise ValueError(f'Missing {key}: {p}')
        return p
    file('params_nh');file('params_sb')
    arrays={}
    for key in ('x_grid','y_grid','bed_pre','erodible_thickness','bed_post'):
        p=file(key);a=np.loadtxt(p)
        if a.shape!=(77,147): raise ValueError(f'{key}: expected (77,147) nodal array, got {a.shape}')
        if not np.isfinite(a).all(): raise ValueError(f'{key} contains missing/nonfinite values')
        arrays[key]=a
    if np.any(arrays['erodible_thickness']<0):
        raise ValueError('Erodible thickness must be nonnegative')
    if not m.get('horizontal_crs') or not m.get('vertical_datum'):
        raise ValueError('Coordinate reference system and vertical datum are required')
    for key,cols in [('boundary_wave',{'time_s','hs_m','tp_s','direction_deg'}),
                     ('boundary_surge',{'time_s','surge_m'}),
                     ('gauge_observations',{'time_s','eta_m'}),
                     ('station_locations',{'id','x_m','y_m'})]:
        p=file(key);a=np.genfromtxt(p,delimiter=',',names=True,dtype=None,encoding='utf-8')
        if not cols.issubset(a.dtype.names or ()):
            raise ValueError(f'{key} needs columns {sorted(cols)}')
        if 'time_s' in cols:
            t=np.atleast_1d(a['time_s']).astype(float)
            if len(t)<2 or not np.isfinite(t).all() or np.any(np.diff(t)<=0):
                raise ValueError(f'{key} time must be finite and strictly increasing')
    return {'status':'input_shapes_checked','note':'Does not establish model reproduction; exact solver and numerical runs still required'}


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('folder')
    args=p.parse_args()
    try: print(json.dumps(validate(args.folder),indent=2))
    except (ValueError,OSError) as e: p.exit(2,f'Inputs not ready: {e}\n')
