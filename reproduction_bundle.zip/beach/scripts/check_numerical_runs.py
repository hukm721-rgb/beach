#!/usr/bin/env python3
"""Verify complete numerical output and repeatability, report grid sensitivity."""
import argparse
import json
from pathlib import Path
import numpy as np
from beach_repro.xbeach import arrays
from beach_repro.audit import ROOT, read_csv, number


def check(coarse, repeat, fine, storms):
    t,x,a=arrays(coarse);tr,xr,ar=arrays(repeat)
    if not np.array_equal(t,tr) or not np.array_equal(x,xr):
        raise AssertionError('Repeated run changed sampling or geometry')
    differences={}
    for name in ('zs','zb','hh'):
        differences[name]=float(np.max(abs(a[name]-ar[name])))
        if not np.array_equal(a[name],ar[name]):
            raise AssertionError(f'Repeated numerical output differs in {name}')
    def stats(case):
        p=ROOT/'results'/Path(case).name/'stage_statistics.csv'
        return read_csv(p)[0]
    c,f=stats(coarse),stats(fine)
    if not (0.1<number(c,'hs_p4_m')<number(c,'hs_p3_m')):
        raise AssertionError('Peak smoke did not demonstrate finite transmitted waves and attenuation')
    grid={
        'coarse_dx_m':number(c,'dx_m'),'fine_dx_m':number(f,'dx_m'),
        'p3_hs_relative_change_pct':100*(number(f,'hs_p3_m')/number(c,'hs_p3_m')-1),
        'p4_hs_relative_change_pct':100*(number(f,'hs_p4_m')/number(c,'hs_p4_m')-1),
        'attenuation_change_percentage_points':number(f,'reduction_pct')-number(c,'reduction_pct'),
        'scope':'Fixed-bed peak smoke only. Two grids do not establish asymptotic convergence or full-storm convergence.'}
    completed={}
    for case in storms:
        p=Path(case)
        receipt=json.loads((p/'run_receipt.json').read_text())
        if receipt['final_time_s']!=21600 or receipt['output_samples']!=21601:
            raise AssertionError(f'Incomplete storm simulation: {case}')
        completed[p.name]=receipt
    result={'repeat_max_absolute_difference':differences,'repeat_bitwise_equal':True,
            'peak_smoke_attenuates_waves':True,'grid_sensitivity':grid,'complete_storm_runs':completed}
    dest=ROOT/'results/numerical_validation.json'
    dest.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    print(json.dumps(result,indent=2))


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--coarse',default=ROOT/'runs/smoke_nh_v3')
    p.add_argument('--repeat',default=ROOT/'runs/smoke_nh_repeat')
    p.add_argument('--fine',default=ROOT/'runs/smoke_nh_fine')
    p.add_argument('--storms',nargs='*',default=[ROOT/'runs/storm_nh',ROOT/'runs/storm_sb'])
    a=p.parse_args();check(a.coarse,a.repeat,a.fine,a.storms)
