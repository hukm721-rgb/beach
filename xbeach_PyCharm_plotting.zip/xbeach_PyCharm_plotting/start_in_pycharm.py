"""在 PyCharm 中只改下面的路径，然后右键 Run 当前文件。"""
from pathlib import Path

# ------------ 你需要修改的设置 ------------
CASE_NH = r"D:\xbeach_APPROX_6H\RUN_THESE\NH"
CASE_SB = ""  # SB 还没运行完就留空；完成后填写 SB 文件夹路径
OBS_CSV = ""  # 没有真实观测就留空，不要把 jonstable/zs0 当作观测

MAKE_SPATIAL_MAPS = True  # 波高场、水面场、侵蚀与示意断面

# 默认使用论文报告的码头观测站约略位置：29.9490 N, -85.4246 E
# 若要选其他模型点，在下面同时填入模型投影坐标，单位 m；不要填经纬度。
CUSTOM_EASTING_M = None
CUSTOM_NORTHING_M = None
# ------------ 以上是设置，下面不用修改 ------------


def main():
    import argparse
    from datetime import datetime
    import json
    from pyproj import Transformer
    from postprocess_2d import run
    from point_series import extract_series, plot_comparison, wet_dry_check

    here = Path(__file__).resolve().parent
    cases = {'NH': CASE_NH, 'SB': CASE_SB}
    cases = {mode: Path(name).expanduser().resolve() for mode, name in cases.items() if name.strip()}
    if not cases:
        raise ValueError('Fill CASE_NH and/or CASE_SB with your real case folder.')
    metadata = {}
    for mode, case in cases.items():
        if not (case / 'output.nc').is_file():
            raise FileNotFoundError(f'{mode}: output.nc not found in {case}. Edit CASE_{mode}, not the script working directory.')
        meta_path = case / 'case_metadata.json'
        if not meta_path.is_file():
            raise FileNotFoundError(f'{meta_path} missing. Keep the case_metadata.json supplied with your 6-h input directory.')
        metadata[mode] = json.loads(meta_path.read_text(encoding='utf-8'))
        expected = 'nonh' if mode == 'NH' else 'surfbeat'
        if metadata[mode]['mode'] != expected:
            raise ValueError(f'{mode}: this case metadata describes a different wave model.')
    out = next(iter(cases.values())).parent / ('figures_Python_' + datetime.now().strftime('%Y%m%d_%H%M%S_%f'))
    out.mkdir()
    series = {}
    chosen_coordinates = {}
    for mode, case in cases.items():
        c = metadata[mode]['configuration']
        if CUSTOM_EASTING_M is not None and CUSTOM_NORTHING_M is not None:
            east, north = float(CUSTOM_EASTING_M), float(CUSTOM_NORTHING_M)
            source = 'user-specified model projection coordinates'
        elif CUSTOM_EASTING_M is None and CUSTOM_NORTHING_M is None:
            crs = c.get('horizontal_crs')
            if not crs:
                raise ValueError('Model horizontal CRS is unknown; cannot locate the paper station from latitude/longitude.')
            if not Transformer.from_crs(crs, crs).target_crs.is_projected:
                raise ValueError('Model CRS must be projected in metres.')
            east, north = Transformer.from_crs('EPSG:4326', crs, always_xy=True).transform(-85.4246, 29.9490)
            source = 'Paper section 4.2 FLBAY03283 rounded lon/lat; interpreted as WGS84, then transformed to model CRS'
        else:
            raise ValueError('Fill BOTH CUSTOM_EASTING_M and CUSTOM_NORTHING_M, or leave both None.')
        chosen_coordinates[mode] = dict(easting_m=east, northing_m=north, source=source,
                                         model_crs=c.get('horizontal_crs'))
        mode_out = out / mode
        mode_out.mkdir()
        print(f'Processing {mode}: {case}')
        series[mode] = extract_series(case / 'output.nc', mode, east, north, mode_out)
        wet_dry_check(case / 'output.nc', mode_out)
        if MAKE_SPATIAL_MAPS:
            args = argparse.Namespace(case=case, output_dir=mode_out / 'maps', points=None,
                stages=here / 'stages_APPROX_FROM_FIG6.csv', transects=here / 'transects_ILLUSTRATIVE.csv',
                observations=None, profiles=None, detrend='linear', sb_average='energy')
            run(args)
    plot_comparison(series, out, OBS_CSV or None)
    (out / 'selected_station.json').write_text(json.dumps(chosen_coordinates, indent=2) + '\n', encoding='utf-8')
    print('\nDONE. Open this folder in Windows Explorer:\n' + str(out))
    print('point_comparison.png: point curves; NH/SB_15min.csv: numbers; wet_dry_check.png: missing-area diagnosis.')
    print('Approximate model inputs/stages/transects do not become an exact reproduction through plotting.')


if __name__ == '__main__':
    main()
