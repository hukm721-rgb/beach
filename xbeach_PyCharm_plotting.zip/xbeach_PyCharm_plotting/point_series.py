"""Extract a real model point; no input boundary or invented observations as predictions."""
import json
from pathlib import Path

import numpy as np
from netCDF4 import Dataset

from postprocess_2d import (masked_values, read_table, save_table, statistics,
                            window_hs)


def nearest_node(E, N, east, north):
    """Reject an out-of-domain station instead of silently snapping to an edge."""
    p0 = np.array([E[0, 0], N[0, 0]])
    vx = np.array([E[0, -1], N[0, -1]]) - p0
    vy = np.array([E[-1, 0], N[-1, 0]]) - p0
    ab = np.linalg.solve(np.column_stack((vx, vy)), np.array([east, north]) - p0)
    if np.any(ab < -1e-6) or np.any(ab > 1 + 1e-6):
        raise ValueError('The requested station is OUTSIDE this model grid. Check the model CRS and placement.')
    d = np.hypot(E - east, N - north)
    j, i = np.unravel_index(np.nanargmin(d), E.shape)
    return int(j), int(i), float(d[j, i])


def extract_series(ncfile, mode, east, north, out):
    out = Path(out)
    out.mkdir(parents=True, exist_ok=True)
    with Dataset(ncfile) as ds:
        needed = ['globaltime', 'globalx', 'globaly', 'zs', 'hh']
        if mode == 'SB':
            needed.append('H')
        missing = [name for name in needed if name not in ds.variables]
        if missing:
            raise ValueError(f'{mode}: output.nc is missing {missing}. SB needs the actual H output (Hrms).')
        t = masked_values(ds['globaltime'][:])
        if len(t) < 900 or not np.isfinite(t).all() or not np.allclose(np.diff(t), 1, atol=.001, rtol=0):
            raise ValueError('Need at least 900 consecutive 1-second output samples; a 120-s demo is insufficient.')
        E, N = masked_values(ds['globalx'][:]), masked_values(ds['globaly'][:])
        if E.ndim != 2 or E.shape != N.shape or ds['zs'].shape != (len(t), *E.shape):
            raise ValueError('Expected native XBeach Python dimensions: time, ny, nx.')
        j, i, distance = nearest_node(E, N, east, north)
        eta = masked_values(ds['zs'][:, j, i])
        depth = masked_values(ds['hh'][:, j, i])
        H = masked_values(ds['H'][:, j, i]) if mode == 'SB' else None
        for name in ('zs', 'hh') + (('H',) if mode == 'SB' else ()):
            if not np.isfinite(np.ma.asarray(ds[name][:, j, i]).compressed()).all():
                raise ValueError(f'{mode}: nonfinite unmasked values in {name}; check simulation stability.')
        location = dict(mode=mode, requested_easting_m=east, requested_northing_m=north,
                        node_easting_m=float(E[j, i]), node_northing_m=float(N[j, i]),
                        nearest_node_distance_m=distance, row_j_zero_based=j, column_i_zero_based=i,
                        first_output_s=float(t[0]), last_output_s=float(t[-1]))
    raw = [dict(time_s=float(t[k]), zs_m=eta[k], hh_m=depth[k],
                **({'Hrms_m': H[k]} if H is not None else {})) for k in range(len(t))]
    save_table(out / f'{mode}_point_raw.csv', raw)
    rows = []
    start = float(t[0])
    while start + 899 <= t[-1] + .001:
        idx = np.flatnonzero((t >= start) & (t < start + 900))
        if len(idx) != 900:
            raise ValueError('Incomplete 900-s time window.')
        hs, dry = window_hs(eta[idx, None], depth[idx, None],
                           H[idx, None] if H is not None else None)
        wet = np.isfinite(eta[idx]).all() and np.isfinite(depth[idx]).all() and (depth[idx] > .01).all()
        rows.append(dict(window_start_s=start, window_end_s=start + 900,
                         time_center_s=float(t[idx].mean()), hs_m=float(hs[0]),
                         surge_m=float(eta[idx].mean()) if wet else np.nan,
                         dry_fraction=float(dry[0])))
        start += 900
    save_table(out / f'{mode}_15min.csv', rows)
    (out / f'{mode}_station.json').write_text(json.dumps(location, indent=2) + '\n', encoding='utf-8')
    print(f'{mode}: last time={t[-1]:g} s; station node j={j}, i={i}; offset={distance:.2f} m; {len(rows)} windows')
    return rows


def plot_comparison(series, out, observations=None):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    out = Path(out)
    obs = read_table(observations) if observations else []
    if observations and not obs:
        raise ValueError('Observation CSV has only headers. Fill it with real gauge observations, or leave OBS_CSV empty.')
    if len({float(r['window_start_s']) for r in obs}) != len(obs):
        raise ValueError('Duplicate observation window_start_s values.')
    fig, axes = plt.subplots(2, 1, figsize=(10, 7), sharex=True)
    styles = {'NH': dict(color='red', marker='o', markerfacecolor='none', linestyle='--'),
              'SB': dict(color='black', marker='*', linestyle=':')}
    metrics = {}
    for mode, rows in series.items():
        for ax, key in zip(axes, ('hs_m', 'surge_m')):
            ax.plot([r['time_center_s'] / 3600 for r in rows], [r[key] for r in rows],
                    label=mode + ' simulation', **styles[mode])
        if obs:
            matches = [(r, o) for r in rows for o in obs
                       if abs(r['window_start_s'] - float(o['window_start_s'])) < .001]
            if not matches:
                raise ValueError('No observation time windows match the model windows. Use seconds since simulation start.')
            metrics[mode] = {}
            for key in ('hs_m', 'surge_m'):
                pairs = [(r[key], float(o[key])) for r, o in matches if o.get(key)]
                metrics[mode][key] = statistics([p[0] for p in pairs], [p[1] for p in pairs])
    if obs:
        for ax, key in zip(axes, ('hs_m', 'surge_m')):
            valid = sorted((r for r in obs if r.get(key)), key=lambda r: float(r['window_start_s']))
            if valid:
                ax.plot([(float(r['window_start_s']) + 449.5) / 3600 for r in valid],
                        [float(r[key]) for r in valid], color='blue', label='Gauge observation')
        (out / 'validation_metrics.json').write_text(json.dumps(metrics, indent=2) + '\n', encoding='utf-8')
    axes[0].set_ylabel('Significant wave height Hs (m)')
    axes[1].set_ylabel('Mean water elevation (m)')
    axes[1].set_xlabel('Time since simulation start (h)')
    for ax in axes:
        ax.grid(alpha=.25)
        ax.legend(frameon=False)
    fig.suptitle('Model point time series | 900-s windows\n' +
                 ('Real observations supplied; see validation_metrics.json' if obs else 'No gauge observations supplied'))
    fig.tight_layout()
    fig.savefig(out / 'point_comparison.png', dpi=180)
    plt.close(fig)


def wet_dry_check(ncfile, out):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib.colors import BoundaryNorm, ListedColormap
    from matplotlib.patches import Patch
    with Dataset(ncfile) as ds:
        E, N = masked_values(ds['globalx'][:]), masked_values(ds['globaly'][:])
        zb, zs, hh = [masked_values(ds[key][-1]) for key in ('zb', 'zs', 'hh')]
        t = float(ds['globaltime'][-1])
    state = np.full(hh.shape, -1.)
    state[np.isfinite(hh) & (hh <= .01)] = 0
    state[np.isfinite(hh) & (hh > .01) & np.isfinite(zs)] = 1
    fig, axes = plt.subplots(1, 3, figsize=(15, 5))
    visible_zs=np.where(np.isfinite(hh)&(hh>.01),zs,np.nan)
    for ax, field, label, cmap in zip(axes[:2], (zb, visible_zs), ('Full bed elevation (m)', 'Water elevation (m)'), ('terrain', 'viridis')):
        if ax is axes[1]:
            ax.pcolormesh(E / 1000, N / 1000, np.zeros(zb.shape), cmap=ListedColormap(['lightgray']), shading='auto')
        p = ax.pcolormesh(E / 1000, N / 1000, field, cmap=cmap, shading='auto')
        fig.colorbar(p, ax=ax, label='m')
        ax.set_title(label)
    cmap = ListedColormap(['lightgray', '#d2b48c', '#2389be'])
    axes[2].pcolormesh(E / 1000, N / 1000, state, cmap=cmap,
                       norm=BoundaryNorm([-1.5, -.5, .5, 1.5], 3), shading='auto')
    axes[2].set_title('Depth / mask diagnostic')
    axes[2].legend(handles=[Patch(color=c, label=l) for c, l in zip(cmap.colors,
                    ('Masked / missing', 'Dry: hh <= 0.01 m', 'Wet'))], loc='best', fontsize=8)
    for ax in axes:
        ax.set_aspect('equal'); ax.set_xlabel('Easting (km)'); ax.set_ylabel('Northing (km)')
    fig.suptitle(f't = {t:g} s | Masked values are not filled with artificial water')
    fig.tight_layout(); fig.savefig(Path(out) / 'wet_dry_check.png', dpi=160); plt.close(fig)
    report = dict(time_s=t, total_nodes=int(hh.size), wet_nodes=int((state == 1).sum()),
                  known_dry_nodes=int((state == 0).sum()), masked_or_missing_nodes=int((state == -1).sum()),
                  missing_bed_nodes=int((~np.isfinite(zb)).sum()),
                  note='Native missing values may be dry-output masks; this count alone does not prove the cause. Compare hh, zb, zs and the run log.')
    (Path(out) / 'wet_dry_report.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
