#!/usr/bin/env python3
"""Memory-bounded 2D XBeach windows, real point comparisons and profile BSS."""
import argparse
import csv
import json
import os
from pathlib import Path

import numpy as np
from netCDF4 import Dataset
from scipy.signal import detrend
from scipy.spatial import cKDTree


def read_table(path):
    with open(path,encoding='utf-8-sig',newline='') as f: return list(csv.DictReader(f))


def save_table(path,rows,fields=None):
    fields=fields or (list(rows[0]) if rows else [])
    with Path(path).open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
        for r in rows:
            w.writerow({k:('' if isinstance(v,(float,np.floating)) and not np.isfinite(v) else v) for k,v in r.items()})


def masked_values(v): return np.ma.asarray(v).filled(np.nan)


def window_hs(eta,depth,H=None,detrending='linear',sb_average='energy'):
    dry=~np.isfinite(depth)|(depth<=.01)
    valid=~dry.any(axis=0)&np.isfinite(eta).all(axis=0)
    result=np.full(eta.shape[1:],np.nan)
    if H is None:
        if valid.any():
            a=detrend(eta[:,valid],axis=0,type='linear' if detrending=='linear' else 'constant')
            result[valid]=4*np.sqrt(np.mean(a*a,axis=0))
    else:
        valid &= np.isfinite(H).all(axis=0)
        h=H[:,valid]
        result[valid]=np.sqrt(2*np.mean(h*h,axis=0)) if sb_average=='energy' else np.sqrt(2)*np.mean(h,axis=0)
    return result,dry.mean(axis=0)


def statistics(pred,obs):
    pred,obs=np.asarray(pred,float),np.asarray(obs,float)
    finite=np.isfinite(pred)&np.isfinite(obs);p,o=pred[finite],obs[finite]
    if not len(p): return {'n':0,'rmse':None,'bias':None,'correlation':None}
    r=float(np.corrcoef(p,o)[0,1]) if len(p)>1 and np.std(p)>0 and np.std(o)>0 else None
    return {'n':len(p),'rmse':float(np.sqrt(np.mean((p-o)**2))),
            'bias':float(np.mean(p-o)),'correlation':r}


def bss(pre,post,model):
    pre,post,model=np.asarray(pre,float),np.asarray(post,float),np.asarray(model,float)
    denominator=np.sum((post-pre)**2)
    return float(1-np.sum((model-post)**2)/denominator) if denominator>0 else None


def locate(rows,E,N,c):
    if not rows: return []
    xy=np.array([[float(r['easting_m']),float(r['northing_m'])] for r in rows])
    angle=np.deg2rad(c['rotation_ccw_deg'])
    de=xy[:,0]-c['origin_easting_m'];dn=xy[:,1]-c['origin_northing_m']
    xx=de*np.cos(angle)+dn*np.sin(angle);yy=-de*np.sin(angle)+dn*np.cos(angle)
    if np.any((xx<-.001)|(xx>c['cross_shore_length_m']+.001)|(yy<-.001)|(yy>c['along_shore_length_m']+.001)):
        raise ValueError('Some validation coordinates fall outside the grid; check CRS, origin and rotation')
    distance,index=cKDTree(np.c_[E.ravel(),N.ravel()]).query(xy)
    return [(int(k//E.shape[1]),int(k%E.shape[1]),float(d)) for k,d in zip(index,distance)]


def run(args):
    case=Path(args.case).resolve();meta=json.loads((case/'case_metadata.json').read_text())
    c=meta['configuration'];mode=meta['mode']
    out=Path(getattr(args,'output_dir',None) or case/'postprocessed')
    if out.exists() and any(out.iterdir()): raise FileExistsError('postprocessed exists; move it before reprocessing')
    out.mkdir(exist_ok=True)
    points=read_table(args.points) if args.points else []
    transects=read_table(args.transects) if getattr(args,'transects',None) else []
    for row in transects:
        if 'x_local_m' in row and 'y_local_m' in row:
            angle=np.deg2rad(c['rotation_ccw_deg']);xx=float(row['x_local_m']);yy=float(row['y_local_m'])
            row['easting_m']=c['origin_easting_m']+xx*np.cos(angle)-yy*np.sin(angle)
            row['northing_m']=c['origin_northing_m']+xx*np.sin(angle)+yy*np.cos(angle)
    if args.points and not points: raise ValueError('Point CSV has headers only; supply real point coordinates')
    ids=[p['id'] for p in points]
    if len(ids)!=len(set(ids)): raise ValueError('Point IDs must be unique')
    results=[];maxima=[]
    os.environ.setdefault('MPLCONFIGDIR',str(out/'matplotlib_cache'))
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    with Dataset(case/'output.nc') as ds:
        t=masked_values(ds['globaltime'][:]);E=masked_values(ds['globalx'][:]);N=masked_values(ds['globaly'][:])
        if len(t)<2 or not np.isfinite(t).all() or not np.allclose(np.diff(t),1,rtol=0,atol=1e-3):
            raise ValueError('Expected finite, uniformly sampled 1 Hz globaltime')
        if not np.isclose(t[-1],c['duration_s'],rtol=0,atol=1e-3):
            raise ValueError('Model did not reach configured final time')
        expected=(c['ny']+1,c['nx']+1)
        if E.shape!=expected or N.shape!=expected or ds['zs'].shape[1:]!=expected:
            raise ValueError('Output axes do not match the configured (ny+1,nx+1) grid')
        locations=locate(points,E,N,c)
        transect_locations=locate(transects,E,N,c)
        initial_bed=masked_values(ds['zb'][0])
        if args.stages:
            stages=read_table(args.stages)
            windows=[(r['stage'],float(r['window_start_s'])) for r in stages]
        else:
            windows=[(f'window_{int(s):06d}',float(s)) for s in np.arange(0,t[-1]-899,900)]
        if not windows: raise ValueError('No complete 900-second window; use at least 900 s for Hs analysis')
        for label,start in windows:
            i=np.flatnonzero((t>=start)&(t<start+900))
            if len(i)!=900 or np.any(np.diff(i)!=1): raise ValueError(f'{label}: need 900 consecutive 1 Hz samples')
            sl=slice(int(i[0]),int(i[-1])+1)
            eta=masked_values(ds['zs'][sl]);depth=masked_values(ds['hh'][sl])
            # Native dry masks are allowed, but actual NaNs/infinities in
            # unmasked wet fields are not silently discarded.
            for key in ('zs','hh'):
                if not np.isfinite(np.ma.asarray(ds[key][sl]).compressed()).all():
                    raise ValueError('Nonfinite wet output: '+key)
            H=masked_values(ds['H'][sl]) if mode=='surfbeat' else None
            if H is not None and not np.isfinite(np.ma.asarray(ds['H'][sl]).compressed()).all():
                raise ValueError('Nonfinite unmasked H output')
            hs,dry=window_hs(eta,depth,H,args.detrend,args.sb_average)
            zb=masked_values(ds['zb'][i[len(i)//2]])
            if not np.isfinite(zb).all(): raise ValueError('Missing/nonfinite bed output')
            instant=eta[len(i)//2].copy()
            middle_depth=depth[len(i)//2]
            instant[~np.isfinite(middle_depth)|(middle_depth<=.01)]=np.nan
            full_wet=np.isfinite(eta).all(axis=0)&np.isfinite(depth).all(axis=0)&(depth>.01).all(axis=0)
            mean_surface=np.full(E.shape,np.nan)
            if full_wet.any(): mean_surface[full_wet]=eta[:,full_wet].mean(axis=0)
            np.savez_compressed(out/f'{label}_fields.npz',easting_m=E,northing_m=N,hs_m=hs,
                                bed_m=zb,dry_fraction=dry,window_start_s=start,window_end_s=start+900,
                                instantaneous_surface_m=instant,mean_surface_m=mean_surface)
            fig,ax=plt.subplots(figsize=(7,6))
            m=ax.pcolormesh(E/1000,N/1000,hs,shading='auto',cmap='viridis')
            fig.colorbar(m,ax=ax,label='Computed Hs (m)')
            ax.set_aspect('equal');ax.set_xlabel('Easting (km)');ax.set_ylabel('Northing (km)')
            quality='SYNTHETIC DEMO' if meta['demo'] else ('APPROXIMATE RECONSTRUCTION' if meta.get('approximate_reconstruction') else 'user-supplied case')
            ax.set_title(f'{mode} | {label} | {quality}')
            fig.tight_layout();fig.savefig(out/f'{label}_hs.png',dpi=150);plt.close(fig)
            fig,ax=plt.subplots(figsize=(7,6))
            p=ax.pcolormesh(E/1000,N/1000,instant,shading='auto',cmap='viridis')
            fig.colorbar(p,ax=ax,label='Instantaneous water elevation (m)')
            ax.set_aspect('equal');ax.set_xlabel('Easting (km)');ax.set_ylabel('Northing (km)')
            ax.set_title(f'{mode} | {label}, t={t[i[len(i)//2]]:g} s\n{quality}',fontsize=10)
            fig.tight_layout();fig.savefig(out/f'{label}_surface.png',dpi=150);plt.close(fig)
            sampled=[]
            for row,(j,k,d) in zip(transects,transect_locations):
                sampled.append({'section':row['section'],'easting_m':float(row['easting_m']),
                    'northing_m':float(row['northing_m']),'x_local_m':float(row['x_local_m']) if row.get('x_local_m') else np.nan,
                    'initial_bed_m':initial_bed[j,k],'bed_m':zb[j,k],'hs_m':hs[j,k],
                    'mean_surface_m':mean_surface[j,k],'instant_surface_m':instant[j,k],
                    'nearest_node_distance_m':d})
            if sampled:
                save_table(out/f'{label}_transects.csv',sampled)
                for section in dict.fromkeys(r['section'] for r in sampled):
                    group=[r for r in sampled if r['section']==section]
                    distance=np.r_[0,np.cumsum(np.hypot(np.diff([r['easting_m'] for r in group]),np.diff([r['northing_m'] for r in group])))]
                    if all(np.isfinite(r['x_local_m']) for r in group): distance=np.array([r['x_local_m'] for r in group])
                    fig,(ax1,ax2)=plt.subplots(2,1,figsize=(9,6),sharex=True)
                    for field,desc,color,ls in [('initial_bed_m','Initial bed','gray','--'),('bed_m','Stage bed (window midpoint)','#946b38','-'),
                         ('instant_surface_m','Instantaneous surface','#2374ab','-'),('mean_surface_m','Mean surface','#56a0a0',':')]:
                        ax1.plot(distance,[r[field] for r in group],label=desc,color=color,ls=ls)
                    ax1.set_ylabel('Elevation (m)');ax1.legend(fontsize=8,ncol=2,frameon=False)
                    ax1.set_title(f'{mode} | {label} | {section}\n{quality}',fontsize=10)
                    ax2.plot(distance,[r['hs_m'] for r in group],color='#2374ab');ax2.set_ylabel('Computed Hs (m)')
                    ax2.set_xlabel('Distance along supplied transect (m)')
                    for ax in (ax1,ax2): ax.grid(alpha=.2)
                    fig.tight_layout();fig.savefig(out/f'{label}_{section}.png',dpi=150);plt.close(fig)
            for p,(j,k,d) in zip(points,locations):
                surface=eta[:,j,k]
                mean=float(np.mean(surface)) if np.isfinite(surface).all() else np.nan
                results.append({'id':p['id'],'stage':label,'window_start_s':start,'window_end_s':start+900,
                                'mode':mode,'hs_m':hs[j,k],'surge_m':mean,'dry_fraction':dry[j,k],
                                'nearest_node_distance_m':d})
        for p,(j,k,d) in zip(points,locations):
            eta=masked_values(ds['zs'][:,j,k]);finite=eta[np.isfinite(eta)]
            maxima.append({'id':p['id'],'max_water_level_m':float(np.max(finite)) if len(finite) else np.nan})
        final_bed=masked_values(ds['zb'][-1]);change=final_bed-initial_bed
        if not np.isfinite(final_bed).all(): raise ValueError('Nonfinite final bed')
        limit=max(float(np.max(np.abs(change))),1e-6)
        fig,axes=plt.subplots(1,3,figsize=(15,5))
        for ax,a,title in zip(axes,[initial_bed,final_bed,change],['Initial bed','Final bed','Change: final - initial']):
            p=ax.pcolormesh(E/1000,N/1000,a,shading='auto',cmap='RdBu_r' if ax is axes[2] else 'terrain',
                **({'vmin':-limit,'vmax':limit} if ax is axes[2] else {}))
            fig.colorbar(p,ax=ax,label='m');ax.set_aspect('equal');ax.set_title(title)
            ax.set_xlabel('Easting (km)');ax.set_ylabel('Northing (km)')
        fig.suptitle(f'{mode} | {quality} | Negative bed change = erosion',fontsize=11)
        fig.tight_layout();fig.savefig(out/'bed_change.png',dpi=150);plt.close(fig)
        np.savez_compressed(out/'bed_change.npz',easting_m=E,northing_m=N,initial_bed_m=initial_bed,
                            final_bed_m=final_bed,bed_change_m=change)
        if args.profiles:
            survey=read_table(args.profiles)
            if not survey: raise ValueError('Survey CSV has no observations')
            positions=locate(survey,E,N,c)
            final=masked_values(ds['zb'][-1]);sampled=[]
            for row,(j,k,d) in zip(survey,positions):
                sampled.append({**row,'model_zb_post_m':float(final[j,k]),'nearest_node_distance_m':d})
            save_table(out/'profile_samples.csv',sampled)
            scores={}
            for section in sorted(set(r['section'] for r in sampled)):
                group=[r for r in sampled if r['section']==section]
                pre=np.array([float(r['zb_pre_m']) for r in group]);post=np.array([float(r['zb_post_m']) for r in group])
                model=np.array([r['model_zb_post_m'] for r in group])
                if not all(np.isfinite(a).all() for a in (pre,post,model)): raise ValueError('Profiles must be finite and datum-aligned')
                scores[section]={**statistics(model,post),'BSS':bss(pre,post,model)}
            (out/'profile_metrics.json').write_text(json.dumps(scores,indent=2)+'\n')
    if points:
        save_table(out/'point_windows.csv',results);save_table(out/'point_maxima.csv',maxima)
        p3={r['stage']:r for r in results if r['id']=='P3'};p4={r['stage']:r for r in results if r['id']=='P4'}
        attenuation=[]
        for stage in p3.keys()&p4.keys():
            h3,h4=p3[stage]['hs_m'],p4[stage]['hs_m']
            reduction=100*(h3-h4)/h3 if np.isfinite(h3) and np.isfinite(h4) and h3>0 else np.nan
            attenuation.append({'stage':stage,'hs_p3_m':h3,'hs_p4_m':h4,'reduction_pct':reduction})
        if attenuation: save_table(out/'attenuation.csv',attenuation)
    if args.observations:
        if not points: raise ValueError('Observation comparison requires point coordinates')
        obs=read_table(args.observations)
        if not obs: raise ValueError('Observation CSV has no real data')
        lookup={(r['id'],float(r['window_start_s'])):r for r in results}
        aligned=[]
        for r in obs:
            key=(r['id'],float(r['window_start_s']))
            if key not in lookup: continue
            model=lookup[key]
            aligned.append({'id':r['id'],'window_start_s':key[1],
                'observed_hs_m':float(r['hs_m']) if r.get('hs_m') else np.nan,
                'model_hs_m':model['hs_m'],'observed_surge_m':float(r['surge_m']) if r.get('surge_m') else np.nan,
                'model_surge_m':model['surge_m']})
        if not aligned: raise ValueError('No matching observation/model windows')
        save_table(out/'aligned_observations.csv',aligned)
        metrics={name:statistics([r['model_'+name+'_m'] for r in aligned],[r['observed_'+name+'_m'] for r in aligned])
                 for name in ('hs','surge')}
        (out/'observation_metrics.json').write_text(json.dumps(metrics,indent=2)+'\n')
    method={'mode':mode,'demo':meta['demo'],'windows':windows,'nh_method':'4*std(eta), ddof=0, detrend='+args.detrend,
            'sb_method':'sqrt(2*mean(H**2))' if args.sb_average=='energy' else 'sqrt(2)*mean(H)',
            'dry_policy':'Hs omitted if any dry sample occurs; no zero filling',
            'point_sampling':'nearest model node, distance reported; input must lie inside grid',
            'instant_surface_time':'middle sample of window','transect_bed_time':'same middle sample as instantaneous surface',
            'warning':'Paper Eq.6 and averaging details are ambiguous; exact author processing unverified'}
    (out/'processing_method.json').write_text(json.dumps(method,indent=2)+'\n')
    print(out)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--case',required=True);p.add_argument('--points');p.add_argument('--stages')
    p.add_argument('--output-dir',help='New empty output directory (default: CASE/postprocessed)')
    p.add_argument('--observations');p.add_argument('--profiles')
    p.add_argument('--transects',help='CSV section,x_local_m,y_local_m or section,easting_m,northing_m')
    p.add_argument('--detrend',choices=['linear','mean'],default='linear')
    p.add_argument('--sb-average',choices=['energy','arithmetic'],default='energy')
    args=p.parse_args()
    try: run(args)
    except (OSError,ValueError,KeyError) as e: p.exit(2,str(e)+'\n')


if __name__=='__main__': main()
