#!/usr/bin/env python3
"""Check full modeled time and optionally all wet output fields."""
import argparse
import json
from pathlib import Path
import numpy as np
from netCDF4 import Dataset


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--case',required=True);p.add_argument('--scan',action='store_true')
    a=p.parse_args();case=Path(a.case)
    meta=json.loads((case/'case_metadata.json').read_text());expected=meta['configuration']['duration_s']
    with Dataset(case/'output.nc') as ds:
        t=np.ma.asarray(ds['globaltime'][:]).filled(np.nan)
        if len(t)<2 or not np.isfinite(t).all(): p.exit(2,'Missing/invalid model times\n')
        print('Mode:',meta['mode']);print('Saved times:',len(t),'first:',t[0],'last:',t[-1])
        print('Variables:',', '.join(ds.variables))
        if not np.isclose(t[-1],expected,rtol=0,atol=.001):
            p.exit(2,f'INCOMPLETE: expected final model time {expected} s\n')
        if not np.allclose(np.diff(t),1,rtol=0,atol=.001): p.exit(2,'Output is not uniform 1 Hz\n')
        bed0=np.ma.asarray(ds['zb'][0]);bed1=np.ma.asarray(ds['zb'][-1])
        if np.ma.getmaskarray(bed0).any() or np.ma.getmaskarray(bed1).any(): p.exit(2,'Missing bed output\n')
        if not np.isfinite(bed0).all() or not np.isfinite(bed1).all(): p.exit(2,'Nonfinite bed output\n')
        delta=bed1-bed0
        print('Bed change range (m):',float(delta.min()),float(delta.max()))
        if a.scan:
            keys=['zs','zb','hh']+(['H'] if meta['mode']=='surfbeat' else [])
            for first in range(0,len(t),900):
                sl=slice(first,min(first+900,len(t)))
                masks={}
                for key in keys:
                    x=np.ma.asarray(ds[key][sl]);masks[key]=np.ma.getmaskarray(x)
                    if not np.isfinite(x.compressed()).all(): p.exit(2,f'Nonfinite unmasked {key} near t={first}\n')
                    if key=='zb' and masks[key].any(): p.exit(2,'Missing bed values\n')
                    if key=='zs' and len(x.compressed()) and np.max(np.abs(x.compressed()))>100:
                        p.exit(2,'Unphysical water elevation above 100 m\n')
                if not np.array_equal(masks['zs'],masks['hh']): p.exit(2,'Inconsistent dry masks\n')
            print('PASS: all wet fields scanned; native dry masks preserved')
    print('PASS: complete modeled duration. This is not validation against paper observations.')


if __name__=='__main__': main()
